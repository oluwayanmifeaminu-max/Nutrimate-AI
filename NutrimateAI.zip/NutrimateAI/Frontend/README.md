# NutriMate AI — Frontend

React + Vite chat UI for NutriMate AI. See the [root README](../README.md) for
the full project overview, screenshots, architecture, and how Gemma 4 is used.

## Setup

```bash
npm install
npm run dev
```

Visit `http://localhost:5173`. Requires the backend running at
`http://localhost:8000` (see `../Backend/README.md`) — override with
`VITE_API_BASE_URL` in a `.env` file (see `.env.example`) if it's elsewhere.

## Structure

- `src/pages/` — `Landing`, `Auth`, `Onboarding`, and `pages/app/` (`Chat`,
  `Timetable`, `Pantry`, `Shopping`, `Profile`) — Chat is the default landing
  screen once inside the app.
- `src/state/AppState.jsx` — shared app state and all backend API calls
  (chat, meal-plan generation, pantry CRUD).
- `src/api.js` — thin fetch wrappers around the backend's REST endpoints.
- `src/components/MealPlanCard.jsx` — the meal-plan generator, embedded
  inline in the chat thread rather than as a separate page.

## Scripts

- `npm run dev` — dev server with HMR
- `npm run build` — production build
- `npm run lint` — Oxlint
