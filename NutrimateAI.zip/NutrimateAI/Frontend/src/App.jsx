import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppStateProvider } from './state/AppState.jsx';
import Landing from './pages/Landing.jsx';
import Auth from './pages/Auth.jsx';
import Onboarding from './pages/Onboarding.jsx';
import AppLayout from './layouts/AppLayout.jsx';
import Timetable from './pages/app/Timetable.jsx';
import Pantry from './pages/app/Pantry.jsx';
import Shopping from './pages/app/Shopping.jsx';
import Chat from './pages/app/Chat.jsx';
import Profile from './pages/app/Profile.jsx';

export default function App() {
  return (
    <AppStateProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Auth mode="login" />} />
          <Route path="/signup" element={<Auth mode="signup" />} />
          <Route path="/onboarding" element={<Onboarding />} />

          <Route path="/app" element={<AppLayout />}>
            <Route index element={<Navigate to="chat" replace />} />
            <Route path="timetable" element={<Timetable />} />
            <Route path="pantry" element={<Pantry />} />
            <Route path="shopping" element={<Shopping />} />
            <Route path="chat" element={<Chat />} />
            <Route path="profile" element={<Profile />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AppStateProvider>
  );
}
