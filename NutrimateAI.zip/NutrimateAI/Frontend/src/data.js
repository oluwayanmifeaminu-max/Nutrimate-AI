import {
  BoxIcon,
  CoinIcon,
  InfoIcon,
  CalendarIcon,
  CartIcon,
  WifiOffIcon,
  SparkleIcon,
  ChatBubbleIcon,
} from './components/Icons.jsx';

export const NAV_DEFS = [
  { key: 'chat', label: 'AI Chat', icon: ChatBubbleIcon },
  { key: 'timetable', label: 'Timetable', icon: CalendarIcon },
  { key: 'pantry', label: 'Pantry', icon: BoxIcon },
  { key: 'shopping', label: 'Shopping', icon: CartIcon },
];

export const FEATURES = [
  {
    title: 'Pantry-first planning',
    body: 'Plans start from what you already own, so you buy less and waste nothing.',
    icon: BoxIcon,
  },
  {
    title: 'Budget-aware AI',
    body: 'Set a weekly budget in Naira and every meal is chosen to fit it.',
    icon: CoinIcon,
  },
  {
    title: 'Explained choices',
    body: 'Every meal comes with a plain-English reason, so you learn as you go.',
    icon: InfoIcon,
  },
  {
    title: 'Weekly timetable',
    body: 'Breakfast, lunch and dinner mapped across the whole week.',
    icon: CalendarIcon,
  },
  {
    title: 'Smart shopping list',
    body: 'Grouped by must-buy, optional and nice-to-have with live totals.',
    icon: CartIcon,
  },
  {
    title: 'Works offline',
    body: 'On-device AI means no data, no internet needed to plan your week.',
    icon: WifiOffIcon,
  },
];

export const TESTIMONIALS = [
  {
    quote: 'It plans around the little I have in my room. My food money finally lasts the whole week.',
    name: 'Chidi A.',
    role: '200L, UNILAG',
    initial: 'C',
    color: '#2E7D32',
  },
  {
    quote: 'The reasons for each meal actually taught me about protein. I feel less clueless now.',
    name: 'Fatima B.',
    role: 'NYSC, Abuja',
    initial: 'F',
    color: '#66BB6A',
  },
  {
    quote: "No wahala with data — it works offline in my hostel. The shopping list is a lifesaver.",
    name: 'Tunde O.',
    role: '400L, OAU',
    initial: 'T',
    color: '#43A047',
  },
];

export const FAQS = [
  {
    q: 'Do I need internet?',
    a: 'No. NutriMate AI runs its planning on your device, so you can generate meal plans completely offline.',
  },
  {
    q: 'Is it really free?',
    a: 'Yes, the core planner is free. You only ever pay for your own groceries.',
  },
  {
    q: 'Can it handle Nigerian meals?',
    a: "Absolutely — it's built around local, affordable ingredients and dishes like jollof, moi moi and yam.",
  },
  {
    q: 'What if my budget is very small?',
    a: 'Set any weekly budget in Naira. The AI adapts portions and ingredients to fit it comfortably.',
  },
];

export const TODAY_MEALS = [
  { slot: 'Breakfast', name: 'Moi Moi & Pap', kcal: 420, protein: 18, time: '25 min', costValue: 650 },
  { slot: 'Lunch', name: 'Jollof Rice & Beans', kcal: 610, protein: 22, time: '40 min', costValue: 900 },
  { slot: 'Dinner', name: 'Yam & Egg Sauce', kcal: 540, protein: 20, time: '30 min', costValue: 750 },
];

export const MEAL_WHY = {
  Breakfast: 'Uses beans you already have and starts your day with 18g protein.',
  Lunch: 'Balanced carbs and protein; the most affordable filling option today.',
  Dinner: 'Uses eggs expiring in 2 days so nothing goes to waste.',
};

export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const SHOP_GROUPS = [
  {
    title: 'Must buy',
    subtitle: "needed for this week's meals",
    tone: 'danger',
    items: [
      { name: 'Eggs (crate)', why: 'For breakfasts & egg sauce', qty: 'x1', priceValue: 1800 },
      { name: 'Tomatoes', why: 'Base for jollof & stew', qty: '6', priceValue: 700 },
      { name: 'Spinach', why: 'Iron for 3 lunches', qty: '2 bunches', priceValue: 500 },
    ],
  },
  {
    title: 'Optional',
    subtitle: 'improves variety',
    tone: 'warn',
    items: [
      { name: 'Chicken (portion)', why: 'Extra protein on Sat', qty: '500 g', priceValue: 2200 },
      { name: 'Plantain', why: 'Cheap calories', qty: '3', priceValue: 600 },
    ],
  },
  {
    title: 'Nice to have',
    subtitle: 'if budget allows',
    tone: 'ok',
    items: [{ name: 'Greek yogurt', why: 'Healthy snack', qty: 'x1', priceValue: 790 }],
  },
];

export const CHAT_PROMPTS = ['What can I cook?', 'I have ₦1,000', 'How do I gain weight?', 'What should I buy?'];

export const GOAL_OPTIONS = ['Lose Weight', 'Gain Weight', 'Maintain Weight', 'Eat Healthier', 'Save Money'];
export const DIET_OPTIONS = ['Vegetarian', 'Vegan', 'Halal', 'High Protein', 'Low Carb', 'Gluten Free'];
export const SKILL_OPTIONS = [
  { label: 'Beginner', desc: 'Simple, few-step meals' },
  { label: 'Intermediate', desc: 'Comfortable with most recipes' },
  { label: 'Advanced', desc: 'Bring on the challenge' },
];
export const EQUIP_OPTIONS = ['Gas Cooker', 'Microwave', 'Electric Cooker', 'Air Fryer', 'Kettle', 'Oven'];
export const DURATION_OPTIONS = ['3 days', '1 week'];
export const PANTRY_CHIPS = ['Beans', 'Rice', 'Eggs', 'Tomatoes', 'Palm Oil', 'Yam'];

export const ALLERGY_OPTIONS = ['Peanut', 'Tree Nut', 'Dairy', 'Egg', 'Gluten', 'Soy', 'Shellfish', 'Fish', 'Sesame'];
export const MEAL_SLOTS = ['Breakfast', 'Lunch', 'Dinner'];
export const COOK_TIME_OPTIONS = [
  { label: 'Fast', desc: '5-10 min' },
  { label: 'Intermediate', desc: '30-60 min' },
  { label: 'Long', desc: '1-2 hr' },
];

export const ONBOARDING_STEP_META = [
  ['Let’s get to know you', 'A few basics so we can personalize your plan.'],
  ['What’s your goal?', 'Pick what matters most — you can choose more than one.'],
  ['What’s your budget?', "We'll build every plan to fit comfortably inside it."],
  ['Any dietary preferences?', 'Tap all that apply.'],
  ['How confident are you cooking?', "We'll match recipe difficulty to you."],
  ['What can you cook with?', 'Select the equipment you have access to.'],
  ['', ''],
];

export const TAG_COLORS = {
  ok: { bg: '#E8F5E9', color: '#2E7D32' },
  warn: { bg: '#FFF4E5', color: '#B45309' },
  danger: { bg: '#FDECEC', color: '#C0392B' },
};
