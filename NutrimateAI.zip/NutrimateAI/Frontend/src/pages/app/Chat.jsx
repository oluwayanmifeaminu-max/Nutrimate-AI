import { useEffect, useRef } from 'react';
import { useAppState } from '../../state/AppState.jsx';
import { SparkleIcon, SendIcon } from '../../components/Icons.jsx';
import MealPlanCard from '../../components/MealPlanCard.jsx';
import ChatMarkdown from '../../components/ChatMarkdown.jsx';
import { CHAT_PROMPTS } from '../../data.js';

export default function Chat() {
  const { state, setChatInput, sendChat, sendPrompt, startMealPlanCard, ensureGreeting } = useAppState();
  const { chat, chatInput, chatLoading } = state;
  const scrollRef = useRef(null);

  useEffect(() => {
    ensureGreeting();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [chat, chatLoading]);

  const onKeyDown = (e) => {
    if (e.key === 'Enter' && !chatLoading) sendChat();
  };

  return (
    <div style={{ maxWidth: 820, margin: '0 auto', height: 'calc(100vh - 68px - 56px)', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
        <div
          style={{
            width: 44,
            height: 44,
            borderRadius: 14,
            background: 'linear-gradient(135deg,#2E7D32,#66BB6A)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <SparkleIcon size={22} stroke="#fff" strokeWidth={2} />
        </div>
        <div>
          <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 19 }}>NutriMate Coach</div>
          <div style={{ fontSize: 13, color: '#66BB6A', fontWeight: 600 }}>● Online · answers offline</div>
        </div>
      </div>

      <div
        ref={scrollRef}
        style={{
          flex: 1,
          overflowY: 'auto',
          background: '#fff',
          border: '1px solid #EEF2EE',
          borderRadius: 20,
          padding: 22,
          display: 'flex',
          flexDirection: 'column',
          gap: 14,
        }}
      >
        {chat.map((m, i) => {
          if (m.type === 'mealplan-card') {
            return (
              <div key={i} style={{ display: 'flex', justifyContent: 'flex-start' }}>
                <MealPlanCard />
              </div>
            );
          }
          const user = m.role === 'user';
          return (
            <div key={i} style={{ display: 'flex', justifyContent: user ? 'flex-end' : 'flex-start' }}>
              <div
                style={{
                  maxWidth: '76%',
                  padding: '13px 16px',
                  borderRadius: 16,
                  fontSize: 14,
                  lineHeight: 1.55,
                  background: user ? '#2E7D32' : '#F3F9F3',
                  color: user ? '#fff' : '#1F2937',
                  borderBottomRightRadius: user ? 4 : 16,
                  borderBottomLeftRadius: user ? 16 : 4,
                }}
              >
                {user ? m.text : <ChatMarkdown text={m.text} />}
              </div>
            </div>
          );
        })}
        {chatLoading && (
          <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
            <div
              style={{
                padding: '13px 16px',
                borderRadius: 16,
                borderBottomLeftRadius: 4,
                background: '#F3F9F3',
                display: 'flex',
                gap: 4,
                alignItems: 'center',
              }}
            >
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: '50%',
                    background: '#66BB6A',
                    animation: 'nmPulse 1s ease-in-out infinite',
                    animationDelay: `${i * 0.15}s`,
                  }}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      <div style={{ marginTop: 14 }}>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
          <button
            onClick={startMealPlanCard}
            style={{ border: '1.5px solid #2E7D32', background: '#E8F5E9', color: '#2E7D32', fontWeight: 700, fontSize: 13, padding: '8px 14px', borderRadius: 999, cursor: 'pointer' }}
          >
            📅 Create a meal plan
          </button>
          {CHAT_PROMPTS.map((text) => (
            <button
              key={text}
              onClick={() => !chatLoading && sendPrompt(text)}
              disabled={chatLoading}
              style={{ border: '1.5px solid #E3EDE3', background: '#fff', color: '#374151', fontWeight: 600, fontSize: 13, padding: '8px 14px', borderRadius: 999, cursor: chatLoading ? 'default' : 'pointer', opacity: chatLoading ? 0.5 : 1 }}
            >
              {text}
            </button>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <input
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={onKeyDown}
            disabled={chatLoading}
            placeholder="Ask about meals, budget, nutrition…"
            style={{ flex: 1, padding: '14px 16px', border: '1.5px solid #E3EDE3', borderRadius: 14, fontSize: 15, fontFamily: 'Inter' }}
          />
          <button
            onClick={sendChat}
            disabled={chatLoading}
            style={{ border: 'none', background: '#2E7D32', color: '#fff', width: 52, borderRadius: 14, cursor: chatLoading ? 'default' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: chatLoading ? 0.6 : 1 }}
          >
            <SendIcon size={20} stroke="#fff" strokeWidth={2} />
          </button>
        </div>
      </div>
    </div>
  );
}
