import { useState } from 'react';
import { BoxIcon } from '../../components/Icons.jsx';
import PantryQuickAdd from '../../components/PantryQuickAdd.jsx';
import { useAppState } from '../../state/AppState.jsx';
import { TAG_COLORS } from '../../data.js';

export default function Pantry() {
  const { state, removePantryItem } = useAppState();
  const { pantry, pantryLoading } = state;
  const [adding, setAdding] = useState(false);

  const expiringSoon = pantry.filter((p) => p.level === 'warn' || p.level === 'danger').length;

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
        <div>
          <h1 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 28, margin: 0 }}>Pantry</h1>
          <p style={{ color: '#6B7280', margin: '6px 0 0' }}>
            {pantry.length} ingredients · {expiringSoon} expiring soon
          </p>
        </div>
        <button
          onClick={() => setAdding((a) => !a)}
          style={{ border: 'none', background: '#2E7D32', color: '#fff', fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, padding: '12px 20px', borderRadius: 12, cursor: 'pointer' }}
        >
          {adding ? 'Close' : '+ Add ingredient'}
        </button>
      </div>

      {adding && (
        <div style={{ background: '#fff', borderRadius: 16, border: '1px solid #EEF2EE', padding: 16, marginBottom: 20, maxWidth: 420 }}>
          <PantryQuickAdd />
        </div>
      )}

      {!pantryLoading && pantry.length === 0 && (
        <div style={{ background: '#fff', borderRadius: 18, border: '1px dashed #E3EDE3', padding: 40, textAlign: 'center', color: '#6B7280' }}>
          Your pantry is empty. Add what you have on hand so plans can use it.
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16 }}>
        {pantry.map((p) => (
          <div key={p.name} style={{ background: '#fff', borderRadius: 18, border: '1px solid #EEF2EE', padding: 18, position: 'relative' }}>
            <button
              onClick={() => removePantryItem(p.name)}
              aria-label={`Remove ${p.name}`}
              style={{
                position: 'absolute',
                top: 10,
                right: 10,
                border: 'none',
                background: 'transparent',
                color: '#CBD5C9',
                cursor: 'pointer',
                fontSize: 16,
                lineHeight: 1,
                padding: 4,
              }}
            >
              ×
            </button>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: '#F7FAF7', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <BoxIcon stroke="#66BB6A" />
              </div>
              <span
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  padding: '4px 9px',
                  borderRadius: 999,
                  background: TAG_COLORS[p.level].bg,
                  color: TAG_COLORS[p.level].color,
                }}
              >
                {p.tag}
              </span>
            </div>
            <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 15 }}>{p.name}</div>
            <div style={{ fontSize: 13, color: '#6B7280', marginTop: 3 }}>{p.qty} · {p.cat}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
