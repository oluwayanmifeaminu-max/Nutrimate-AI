import { useNavigate } from 'react-router-dom';
import { useAppState, naira } from '../../state/AppState.jsx';
import { LeafIcon, DotsIcon } from '../../components/Icons.jsx';
import { TODAY_MEALS, MEAL_WHY, DAYS } from '../../data.js';

export default function Timetable() {
  const navigate = useNavigate();
  const { state, setDay } = useAppState();
  const { day, generatedPlan } = state;

  const dayIndex = DAYS.indexOf(day);
  const planDay = generatedPlan?.days?.[dayIndex];

  const dayMeals = generatedPlan
    ? (planDay?.slots || []).map((m) => ({
        slot: m.slot,
        name: m.name,
        kcal: m.kcal,
        protein: m.protein_g,
        time: `${m.cook_time_mins} min`,
        costValue: m.estimated_cost,
        why: m.uses_pantry_items.length
          ? `Uses what you already have: ${m.uses_pantry_items.join(', ')}.`
          : "Doesn't use anything from your current pantry.",
      }))
    : TODAY_MEALS.map((m) => ({ ...m, why: MEAL_WHY[m.slot] }));

  const headerSub = generatedPlan
    ? `${naira(generatedPlan.total_cost)} planned${generatedPlan.days.length < DAYS.length ? ` over ${generatedPlan.days.length} days` : ' this week'} · ${generatedPlan.avg_protein_per_meal_g}g avg protein/meal`
    : '₦11,240 planned this week · 88 avg nutrition score';

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
        <div>
          <h1 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 28, margin: 0 }}>Weekly timetable</h1>
          <p style={{ color: '#6B7280', margin: '6px 0 0' }}>{headerSub}</p>
        </div>
        <button
          onClick={() => navigate('/app/shopping')}
          style={{ border: 'none', background: '#2E7D32', color: '#fff', fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, padding: '12px 20px', borderRadius: 12, cursor: 'pointer' }}
        >
          View shopping list
        </button>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20, overflowX: 'auto', paddingBottom: 4 }}>
        {DAYS.map((d) => {
          const active = day === d;
          return (
            <button
              key={d}
              onClick={() => setDay(d)}
              style={{
                flexShrink: 0,
                padding: '10px 20px',
                borderRadius: 12,
                fontFamily: "'Plus Jakarta Sans'",
                fontWeight: 700,
                fontSize: 14,
                cursor: 'pointer',
                border: `1.5px solid ${active ? '#2E7D32' : '#E3EDE3'}`,
                background: active ? '#2E7D32' : '#fff',
                color: active ? '#fff' : '#374151',
              }}
            >
              {d}
            </button>
          );
        })}
      </div>

      {generatedPlan && !planDay ? (
        <div style={{ background: '#fff', borderRadius: 20, border: '1px solid #EEF2EE', padding: 40, textAlign: 'center', color: '#6B7280' }}>
          Your current plan only covers {generatedPlan.days.length} day{generatedPlan.days.length === 1 ? '' : 's'} — pick one of the first{' '}
          {generatedPlan.days.length} tabs above.
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>
          {dayMeals.map((m) => (
            <div key={m.slot} style={{ background: '#fff', borderRadius: 20, border: '1px solid #EEF2EE', overflow: 'hidden', animation: 'nmFade .4s ease' }}>
              <div style={{ height: 140, background: 'repeating-linear-gradient(135deg,#EAF3EA,#EAF3EA 10px,#F7FAF7 10px,#F7FAF7 20px)', position: 'relative' }}>
                <span
                  style={{
                    position: 'absolute',
                    top: 12,
                    left: 12,
                    background: '#fff',
                    color: '#2E7D32',
                    fontWeight: 700,
                    fontSize: 11,
                    textTransform: 'uppercase',
                    letterSpacing: '.05em',
                    padding: '5px 11px',
                    borderRadius: 999,
                  }}
                >
                  {m.slot}
                </span>
                <span
                  style={{
                    position: 'absolute',
                    top: 12,
                    right: 12,
                    background: 'rgba(255,255,255,.9)',
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                  }}
                >
                  <LeafIcon size={16} stroke="#EF5350" strokeWidth={2} />
                </span>
              </div>
              <div style={{ padding: 18 }}>
                <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 17, marginBottom: 12 }}>{m.name}</div>
                <div style={{ display: 'flex', gap: 14, marginBottom: 12, flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 12, color: '#6B7280' }}>
                    <b style={{ color: '#1F2937', fontFamily: "'Plus Jakarta Sans'" }}>{m.kcal}</b> kcal
                  </span>
                  <span style={{ fontSize: 12, color: '#6B7280' }}>
                    <b style={{ color: '#1F2937', fontFamily: "'Plus Jakarta Sans'" }}>{m.protein}g</b> protein
                  </span>
                  <span style={{ fontSize: 12, color: '#6B7280' }}>
                    <b style={{ color: '#1F2937', fontFamily: "'Plus Jakarta Sans'" }}>{m.time}</b>
                  </span>
                  <span style={{ fontSize: 12, color: '#6B7280' }}>
                    <b style={{ color: '#2E7D32', fontFamily: "'Plus Jakarta Sans'" }}>{naira(m.costValue)}</b>
                  </span>
                </div>
                <div style={{ background: '#F3F9F3', borderRadius: 11, padding: '10px 12px', fontSize: 12, color: '#4B5563', lineHeight: 1.5, marginBottom: 14, borderLeft: '3px solid #66BB6A' }}>
                  <b style={{ color: '#2E7D32' }}>Why:</b> {m.why}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button style={{ flex: 1, border: '1px solid #E3EDE3', background: '#fff', color: '#374151', fontWeight: 600, fontSize: 13, padding: 9, borderRadius: 10, cursor: 'pointer' }}>
                    Recipe
                  </button>
                  <button style={{ flex: 1, border: '1px solid #E3EDE3', background: '#fff', color: '#374151', fontWeight: 600, fontSize: 13, padding: 9, borderRadius: 10, cursor: 'pointer' }}>
                    Replace
                  </button>
                  <button style={{ border: '1px solid #E3EDE3', background: '#fff', width: 38, borderRadius: 10, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <DotsIcon size={16} stroke="#6B7280" strokeWidth={2} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
