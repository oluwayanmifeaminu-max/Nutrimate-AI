import { useAppState, naira } from '../../state/AppState.jsx';
import { SHOP_GROUPS, TAG_COLORS } from '../../data.js';

export default function Shopping() {
  const { state } = useAppState();
  const list = state.generatedPlan?.shopping_list;

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
        <div>
          <h1 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 28, margin: 0 }}>Shopping list</h1>
          <p style={{ color: '#6B7280', margin: '6px 0 0' }}>
            Estimated total <b style={{ color: '#2E7D32' }}>{naira(list ? list.total : 6390)}</b> · optimized for this week's plan
          </p>
        </div>
        <button style={{ border: '1.5px solid #E3EDE3', background: '#fff', color: '#1F2937', fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, padding: '12px 20px', borderRadius: 12, cursor: 'pointer' }}>
          Export list
        </button>
      </div>

      {list ? (
        <div style={{ maxWidth: 760 }}>
          <div style={{ background: '#fff', borderRadius: 20, border: '1px solid #EEF2EE', padding: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <span
                style={{
                  fontFamily: "'Plus Jakarta Sans'",
                  fontWeight: 700,
                  fontSize: 13,
                  padding: '6px 13px',
                  borderRadius: 999,
                  background: TAG_COLORS.danger.bg,
                  color: TAG_COLORS.danger.color,
                }}
              >
                Needed for your plan
              </span>
              <span style={{ fontSize: 13, color: '#9CA3AF' }}>everything not already in your pantry</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {list.items.map((it) => (
                <div key={it.name} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 12, background: '#F7FAF7', borderRadius: 13 }}>
                  <div style={{ width: 22, height: 22, borderRadius: 7, border: '2px solid #CBD5C9', flexShrink: 0 }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{it.name}</div>
                  </div>
                  <div style={{ fontSize: 13, color: '#6B7280' }}>
                    {it.quantity} {it.unit}
                  </div>
                  <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, color: '#2E7D32', width: 80, textAlign: 'right' }}>
                    {naira(it.subtotal)}
                  </div>
                </div>
              ))}
              {list.items.length === 0 && (
                <div style={{ color: '#6B7280', fontSize: 14, padding: '8px 0' }}>Nothing to buy — your pantry covers this plan.</div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 760 }}>
          {SHOP_GROUPS.map((grp) => (
            <div key={grp.title} style={{ background: '#fff', borderRadius: 20, border: '1px solid #EEF2EE', padding: 22 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
                <span
                  style={{
                    fontFamily: "'Plus Jakarta Sans'",
                    fontWeight: 700,
                    fontSize: 13,
                    padding: '6px 13px',
                    borderRadius: 999,
                    background: TAG_COLORS[grp.tone].bg,
                    color: TAG_COLORS[grp.tone].color,
                  }}
                >
                  {grp.title}
                </span>
                <span style={{ fontSize: 13, color: '#9CA3AF' }}>{grp.subtitle}</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {grp.items.map((it) => (
                  <div key={it.name} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 12, background: '#F7FAF7', borderRadius: 13 }}>
                    <div style={{ width: 22, height: 22, borderRadius: 7, border: '2px solid #CBD5C9', flexShrink: 0 }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{it.name}</div>
                      <div style={{ fontSize: 12, color: '#9CA3AF' }}>{it.why}</div>
                    </div>
                    <div style={{ fontSize: 13, color: '#6B7280' }}>{it.qty}</div>
                    <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, color: '#2E7D32', width: 70, textAlign: 'right' }}>
                      {naira(it.priceValue)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
