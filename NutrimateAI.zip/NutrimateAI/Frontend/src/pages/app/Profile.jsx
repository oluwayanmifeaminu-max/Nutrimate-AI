import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppState, naira } from '../../state/AppState.jsx';

export default function Profile() {
  const navigate = useNavigate();
  const { state, setName } = useAppState();
  const { goals, budget, equip } = state;
  const [editingName, setEditingName] = useState(false);
  const [draftName, setDraftName] = useState(state.name);

  const displayName = state.name.trim() || 'Add your name';
  const avatarLetter = state.name.trim() ? state.name.trim().charAt(0).toUpperCase() : '?';

  const startEditing = () => {
    setDraftName(state.name);
    setEditingName(true);
  };
  const saveName = (e) => {
    e.preventDefault();
    setName(draftName.trim());
    setEditingName(false);
  };

  const settingsRows = [
    { label: 'Goals & preferences', value: goals.join(', ') },
    { label: 'Budget', value: naira(budget) + ' / week' },
    { label: 'Equipment', value: equip.join(', ') },
    { label: 'Notifications', value: 'Meal reminders on' },
  ];

  return (
    <div>
      <h1 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 28, margin: '0 0 24px' }}>Profile &amp; settings</h1>
      <div style={{ maxWidth: 640, background: '#fff', borderRadius: 22, border: '1px solid #EEF2EE', padding: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18, paddingBottom: 24, borderBottom: '1px solid #EEF2EE' }}>
          <div
            style={{
              width: 72,
              height: 72,
              borderRadius: '50%',
              background: 'linear-gradient(135deg,#66BB6A,#2E7D32)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
              fontFamily: "'Plus Jakarta Sans'",
              fontWeight: 800,
              fontSize: 28,
              flexShrink: 0,
            }}
          >
            {avatarLetter}
          </div>
          {editingName ? (
            <form onSubmit={saveName} style={{ display: 'flex', gap: 8, alignItems: 'center', flex: 1 }}>
              <input
                autoFocus
                value={draftName}
                onChange={(e) => setDraftName(e.target.value)}
                placeholder="Your name"
                style={{ flex: 1, padding: '10px 12px', border: '1.5px solid #E3EDE3', borderRadius: 10, fontSize: 16, fontFamily: "'Plus Jakarta Sans'" }}
              />
              <button
                type="submit"
                style={{ border: 'none', background: '#2E7D32', color: '#fff', fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, padding: '10px 16px', borderRadius: 10, cursor: 'pointer' }}
              >
                Save
              </button>
              <button
                type="button"
                onClick={() => setEditingName(false)}
                style={{ border: '1.5px solid #E3EDE3', background: '#fff', color: '#374151', fontWeight: 600, padding: '10px 14px', borderRadius: 10, cursor: 'pointer' }}
              >
                Cancel
              </button>
            </form>
          ) : (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 22 }}>{displayName}</div>
                <button
                  onClick={startEditing}
                  style={{ border: 'none', background: 'transparent', color: '#2E7D32', fontWeight: 700, fontSize: 13, cursor: 'pointer', padding: 0 }}
                >
                  Edit
                </button>
              </div>
              <div style={{ color: '#6B7280' }}>{state.skill} cook</div>
            </div>
          )}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', marginTop: 8 }}>
          {settingsRows.map((r) => (
            <div key={r.label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 0', borderBottom: '1px solid #F0F4F0' }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{r.label}</div>
                <div style={{ fontSize: 13, color: '#9CA3AF' }}>{r.value}</div>
              </div>
              <span style={{ color: '#9CA3AF' }}>›</span>
            </div>
          ))}
        </div>
        <button
          onClick={() => navigate('/')}
          style={{ marginTop: 20, border: '1.5px solid #FCA5A5', background: '#fff', color: '#EF5350', fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, padding: '12px 20px', borderRadius: 12, cursor: 'pointer' }}
        >
          Log out
        </button>
      </div>
    </div>
  );
}
