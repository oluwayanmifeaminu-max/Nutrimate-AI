import { useNavigate } from 'react-router-dom';
import { LeafLogoIcon } from '../components/Icons.jsx';

const inputStyle = {
  width: '100%',
  padding: '13px 15px',
  border: '1.5px solid #E3EDE3',
  borderRadius: 12,
  fontSize: 15,
  fontFamily: 'Inter',
};
const labelStyle = { fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 };

export default function Auth({ mode }) {
  const navigate = useNavigate();
  const isSignup = mode === 'signup';

  const title = isSignup ? 'Create your account' : 'Welcome back';
  const sub = isSignup ? 'Start eating smarter in two minutes.' : "Log in to see today's plan.";
  const cta = isSignup ? 'Create account' : 'Log in';

  const submit = (e) => {
    e.preventDefault();
    if (isSignup) navigate('/onboarding');
    else navigate('/app/chat');
  };

  return (
    <div style={{ minHeight: '100vh', display: 'grid', gridTemplateColumns: '1fr 1fr' }}>
      <div
        style={{
          background: 'linear-gradient(160deg,#2E7D32,#1B5E20)',
          padding: 56,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          color: '#fff',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              width: 38,
              height: 38,
              borderRadius: 12,
              background: 'rgba(255,255,255,.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <LeafLogoIcon size={20} stroke="#fff" strokeWidth={2.2} />
          </div>
          <span style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 20 }}>NutriMate AI</span>
        </div>
        <div>
          <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 34, lineHeight: 1.2, marginBottom: 18 }}>
            "I stopped wasting food and I'm saving ₦8,000 a week."
          </div>
          <div style={{ opacity: 0.85 }}>Blessing · 300-level, University of Ibadan</div>
        </div>
        <div style={{ opacity: 0.7, fontSize: 13 }}>Your data stays on your device.</div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
        <form onSubmit={submit} style={{ width: '100%', maxWidth: 400, animation: 'nmFade .5s ease' }}>
          <h2 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 30, margin: '0 0 8px' }}>{title}</h2>
          <p style={{ color: '#6B7280', margin: '0 0 28px' }}>{sub}</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {isSignup && (
              <div>
                <label style={labelStyle}>Full name</label>
                <input placeholder="Ada Obi" style={inputStyle} />
              </div>
            )}
            <div>
              <label style={labelStyle}>Email</label>
              <input placeholder="you@student.edu.ng" style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>Password</label>
              <input type="password" placeholder="••••••••" style={inputStyle} />
            </div>
          </div>
          <button
            type="submit"
            style={{
              width: '100%',
              marginTop: 22,
              border: 'none',
              background: '#2E7D32',
              color: '#fff',
              fontFamily: "'Plus Jakarta Sans'",
              fontWeight: 700,
              fontSize: 16,
              padding: 15,
              borderRadius: 12,
              cursor: 'pointer',
              boxShadow: '0 8px 20px rgba(46,125,50,.25)',
            }}
          >
            {cta}
          </button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '22px 0', color: '#9CA3AF', fontSize: 13 }}>
            <div style={{ flex: 1, height: 1, background: '#E3EDE3' }} />
            or
            <div style={{ flex: 1, height: 1, background: '#E3EDE3' }} />
          </div>
          <div style={{ display: 'flex', gap: 12 }}>
            <button
              type="button"
              style={{
                flex: 1,
                border: '1.5px solid #E3EDE3',
                background: '#fff',
                padding: 12,
                borderRadius: 12,
                fontWeight: 600,
                fontSize: 14,
                cursor: 'pointer',
                fontFamily: "'Plus Jakarta Sans'",
              }}
            >
              Google
            </button>
            <button
              type="button"
              style={{
                flex: 1,
                border: '1.5px solid #E3EDE3',
                background: '#fff',
                padding: 12,
                borderRadius: 12,
                fontWeight: 600,
                fontSize: 14,
                cursor: 'pointer',
                fontFamily: "'Plus Jakarta Sans'",
              }}
            >
              Apple
            </button>
          </div>
          <div style={{ textAlign: 'center', marginTop: 24, fontSize: 14, color: '#6B7280' }}>
            {isSignup ? (
              <span>
                Already have an account?{' '}
                <a href="/login" onClick={(e) => { e.preventDefault(); navigate('/login'); }} style={{ fontWeight: 700 }}>
                  Log in
                </a>
              </span>
            ) : (
              <span>
                New here?{' '}
                <a href="/signup" onClick={(e) => { e.preventDefault(); navigate('/signup'); }} style={{ fontWeight: 700 }}>
                  Create an account
                </a>
              </span>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
