import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppState, naira } from '../state/AppState.jsx';
import { GOAL_OPTIONS, DIET_OPTIONS, SKILL_OPTIONS, EQUIP_OPTIONS, ONBOARDING_STEP_META } from '../data.js';

const chipBase = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  padding: '14px 16px',
  borderRadius: 13,
  fontFamily: "'Plus Jakarta Sans'",
  fontWeight: 600,
  fontSize: 14,
  cursor: 'pointer',
  textAlign: 'left',
};
const optStyle = (sel) => ({
  ...chipBase,
  border: sel ? '1.5px solid #2E7D32' : '1.5px solid #E3EDE3',
  background: sel ? '#E8F5E9' : '#fff',
  color: sel ? '#2E7D32' : '#374151',
});
const pillBase = {
  padding: '11px 18px',
  borderRadius: 999,
  fontFamily: "'Plus Jakarta Sans'",
  fontWeight: 600,
  fontSize: 14,
  cursor: 'pointer',
};
const pillStyle = (sel) => ({
  ...pillBase,
  border: sel ? '1.5px solid #2E7D32' : '1.5px solid #E3EDE3',
  background: sel ? '#E8F5E9' : '#fff',
  color: sel ? '#2E7D32' : '#374151',
});
const inputStyle = {
  width: '100%',
  padding: '13px 15px',
  border: '1.5px solid #E3EDE3',
  borderRadius: 12,
  fontSize: 15,
};
const labelStyle = { fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 };

export default function Onboarding() {
  const navigate = useNavigate();
  const { state, toggle, setBudget, setSkill, setName } = useAppState();
  const [step, setStep] = useState(1);

  const nextStep = () => {
    if (step >= 7) {
      navigate('/app/chat');
      return;
    }
    setStep((s) => s + 1);
  };
  const prevStep = () => setStep((s) => Math.max(1, s - 1));

  const [title, sub] = step === 7 ? ['', ''] : ONBOARDING_STEP_META[step - 1];
  const pct = Math.round((step / 7) * 100) + '%';
  const nextLabel = step === 7 ? 'Go to AI chat →' : step === 6 ? 'Finish' : 'Continue';

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
      <div style={{ width: '100%', maxWidth: 640 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 32 }}>
          <div style={{ flex: 1, height: 8, background: '#E3EDE3', borderRadius: 999, overflow: 'hidden' }}>
            <div
              style={{
                height: '100%',
                background: 'linear-gradient(90deg,#66BB6A,#2E7D32)',
                borderRadius: 999,
                transition: 'width .4s ease',
                width: pct,
              }}
            />
          </div>
          <div style={{ fontWeight: 700, fontSize: 13, color: '#6B7280', whiteSpace: 'nowrap' }}>Step {step} of 7</div>
        </div>

        <div
          style={{
            background: '#fff',
            borderRadius: 24,
            padding: 40,
            border: '1px solid #EEF2EE',
            boxShadow: '0 20px 50px rgba(16,24,40,.06)',
            minHeight: 380,
            animation: 'nmFade .4s ease',
          }}
          key={step}
        >
          <h2 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 26, margin: '0 0 6px' }}>{title}</h2>
          <p style={{ color: '#6B7280', margin: '0 0 26px' }}>{sub}</p>

          {step === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <label style={labelStyle}>Name</label>
                <input
                  value={state.name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ada"
                  style={inputStyle}
                />
              </div>
              <div style={{ display: 'flex', gap: 14 }}>
                <div style={{ flex: 1 }}>
                  <label style={labelStyle}>Age</label>
                  <input placeholder="21" style={inputStyle} />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={labelStyle}>Gender</label>
                  <input placeholder="Female" style={inputStyle} />
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {GOAL_OPTIONS.map((g) => {
                const selected = state.goals.includes(g);
                return (
                  <button key={g} onClick={() => toggle('goals', g)} style={optStyle(selected)}>
                    {g}
                    {selected && <span style={{ marginLeft: 'auto', color: '#2E7D32' }}>✓</span>}
                  </button>
                );
              })}
            </div>
          )}

          {step === 3 && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
                <span style={{ fontWeight: 600, color: '#374151', fontSize: 14 }}>Weekly budget</span>
                <span style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 28, color: '#2E7D32' }}>
                  {naira(state.budget)}
                </span>
              </div>
              <input
                type="range"
                min={3000}
                max={30000}
                step={500}
                value={state.budget}
                onChange={(e) => setBudget(parseInt(e.target.value, 10))}
                style={{ width: '100%', accentColor: '#2E7D32', height: 6 }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#9CA3AF', fontSize: 12, marginTop: 6 }}>
                <span>₦3,000</span>
                <span>₦30,000</span>
              </div>
              <div style={{ marginTop: 22, background: '#F7FAF7', borderRadius: 14, padding: 16, fontSize: 14, color: '#4B5563', lineHeight: 1.5 }}>
                That's about <b style={{ color: '#2E7D32' }}>{naira(Math.round(state.budget / 7))}</b> per day. We'll plan
                meals to stay comfortably under this.
              </div>
            </div>
          )}

          {step === 4 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {DIET_OPTIONS.map((d) => (
                <button key={d} onClick={() => toggle('diet', d)} style={pillStyle(state.diet.includes(d))}>
                  {d}
                </button>
              ))}
            </div>
          )}

          {step === 5 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {SKILL_OPTIONS.map((o) => {
                const selected = state.skill === o.label;
                return (
                  <button
                    key={o.label}
                    onClick={() => setSkill(o.label)}
                    style={{ ...optStyle(selected), justifyContent: 'space-between' }}
                  >
                    <div style={{ textAlign: 'left' }}>
                      <div style={{ fontWeight: 700, fontFamily: "'Plus Jakarta Sans'", fontSize: 15 }}>{o.label}</div>
                      <div style={{ fontSize: 13, color: '#6B7280', fontWeight: 400 }}>{o.desc}</div>
                    </div>
                    {selected && <span style={{ marginLeft: 'auto', color: '#2E7D32', fontSize: 18 }}>✓</span>}
                  </button>
                );
              })}
            </div>
          )}

          {step === 6 && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {EQUIP_OPTIONS.map((e) => {
                const selected = state.equip.includes(e);
                return (
                  <button
                    key={e}
                    onClick={() => toggle('equip', e)}
                    style={{ ...optStyle(selected), justifyContent: 'space-between' }}
                  >
                    {e}
                    {selected && <span style={{ marginLeft: 'auto', color: '#2E7D32' }}>✓</span>}
                  </button>
                );
              })}
            </div>
          )}

          {step === 7 && (
            <div style={{ textAlign: 'center', padding: '20px 0' }}>
              <div
                style={{
                  width: 96,
                  height: 96,
                  borderRadius: '50%',
                  background: '#E8F5E9',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 22px',
                  animation: 'nmPop .6s ease',
                }}
              >
                <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="#2E7D32" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 6 9 17l-5-5" />
                </svg>
              </div>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 24, marginBottom: 8 }}>
                You're all set, chef!
              </div>
              <p style={{ color: '#6B7280', margin: '0 auto', maxWidth: 360 }}>
                We've got everything we need to build your first smart meal plan. Let's go.
              </p>
            </div>
          )}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 24 }}>
          <button
            onClick={prevStep}
            style={{
              border: '1.5px solid #E3EDE3',
              background: '#fff',
              color: '#374151',
              fontFamily: "'Plus Jakarta Sans'",
              fontWeight: 700,
              padding: '14px 24px',
              borderRadius: 12,
              cursor: 'pointer',
              visibility: step === 1 ? 'hidden' : 'visible',
            }}
          >
            Back
          </button>
          <button
            onClick={nextStep}
            style={{
              border: 'none',
              background: '#2E7D32',
              color: '#fff',
              fontFamily: "'Plus Jakarta Sans'",
              fontWeight: 700,
              padding: '14px 30px',
              borderRadius: 12,
              cursor: 'pointer',
              boxShadow: '0 8px 20px rgba(46,125,50,.25)',
            }}
          >
            {nextLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
