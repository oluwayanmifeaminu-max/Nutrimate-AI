import { useNavigate } from 'react-router-dom';
import { LeafLogoIcon, SparkleIcon } from '../components/Icons.jsx';
import { FEATURES, TESTIMONIALS, FAQS } from '../data.js';

const navLink = { fontWeight: 600, fontSize: 14, color: '#374151' };
const ghostBtn = {
  border: 'none',
  background: 'transparent',
  fontFamily: "'Plus Jakarta Sans'",
  fontWeight: 700,
  fontSize: 14,
  color: '#1F2937',
  cursor: 'pointer',
};
const primaryBtn = {
  border: 'none',
  background: '#2E7D32',
  color: '#fff',
  fontFamily: "'Plus Jakarta Sans'",
  fontWeight: 700,
  fontSize: 14,
  padding: '11px 20px',
  borderRadius: 12,
  cursor: 'pointer',
  boxShadow: '0 6px 16px rgba(46,125,50,.25)',
};

export default function Landing() {
  const navigate = useNavigate();
  const goSignup = () => navigate('/signup');
  const goLogin = () => navigate('/login');
  const goApp = () => navigate('/app/chat');

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* header */}
      <div
        style={{
          maxWidth: 1200,
          margin: '0 auto',
          padding: '22px 28px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              width: 38,
              height: 38,
              borderRadius: 12,
              background: 'linear-gradient(135deg,#2E7D32,#66BB6A)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <LeafLogoIcon size={20} stroke="#fff" strokeWidth={2.2} />
          </div>
          <span style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 20 }}>
            NutriMate<span style={{ color: '#2E7D32' }}> AI</span>
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 28 }}>
          <a href="#features" style={navLink}>Features</a>
          <a href="#how" style={navLink}>How it works</a>
          <a href="#faq" style={navLink}>FAQ</a>
          <button onClick={goLogin} style={ghostBtn}>Log in</button>
          <button onClick={goSignup} style={primaryBtn}>Get started</button>
        </div>
      </div>

      {/* hero */}
      <div
        style={{
          maxWidth: 1200,
          margin: '0 auto',
          padding: '40px 28px 20px',
          display: 'grid',
          gridTemplateColumns: '1.05fr .95fr',
          gap: 48,
          alignItems: 'center',
        }}
      >
        <div style={{ animation: 'nmFade .6s ease' }}>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
              background: '#E8F5E9',
              color: '#2E7D32',
              fontWeight: 700,
              fontSize: 13,
              padding: '8px 14px',
              borderRadius: 999,
              marginBottom: 22,
            }}
          >
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#2E7D32', display: 'inline-block' }} />
            Works offline · Powered by on-device AI
          </div>
          <h1
            style={{
              fontFamily: "'Plus Jakarta Sans'",
              fontWeight: 800,
              fontSize: 56,
              lineHeight: 1.05,
              margin: '0 0 20px',
              letterSpacing: '-.02em',
              textWrap: 'balance',
            }}
          >
            Tell us what you have. We'll help you eat healthier.
          </h1>
          <p style={{ fontSize: 18, lineHeight: 1.6, color: '#4B5563', maxWidth: 520, margin: '0 0 30px' }}>
            NutriMate AI builds smart, affordable meal plans around your real pantry, your budget, and your kitchen —
            not a shopping list you can't afford. Built for students.
          </p>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            <button
              onClick={goSignup}
              style={{
                border: 'none',
                background: '#2E7D32',
                color: '#fff',
                fontFamily: "'Plus Jakarta Sans'",
                fontWeight: 700,
                fontSize: 16,
                padding: '16px 28px',
                borderRadius: 14,
                cursor: 'pointer',
                boxShadow: '0 10px 24px rgba(46,125,50,.28)',
              }}
            >
              Plan my first week
            </button>
            <button
              onClick={goApp}
              style={{
                border: '1.5px solid #CBD5C9',
                background: '#fff',
                color: '#1F2937',
                fontFamily: "'Plus Jakarta Sans'",
                fontWeight: 700,
                fontSize: 16,
                padding: '16px 26px',
                borderRadius: 14,
                cursor: 'pointer',
              }}
            >
              View live demo
            </button>
          </div>
          <div style={{ display: 'flex', gap: 28, marginTop: 38 }}>
            <div>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 26, color: '#2E7D32' }}>₦0</div>
              <div style={{ fontSize: 13, color: '#6B7280', fontWeight: 500 }}>to start</div>
            </div>
            <div style={{ width: 1, background: '#E3EDE3' }} />
            <div>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 26, color: '#2E7D32' }}>30%</div>
              <div style={{ fontSize: 13, color: '#6B7280', fontWeight: 500 }}>less food waste</div>
            </div>
            <div style={{ width: 1, background: '#E3EDE3' }} />
            <div>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 26, color: '#2E7D32' }}>12k+</div>
              <div style={{ fontSize: 13, color: '#6B7280', fontWeight: 500 }}>students</div>
            </div>
          </div>
        </div>

        <div style={{ position: 'relative', animation: 'nmFade .8s ease' }}>
          <div
            style={{
              background: '#fff',
              borderRadius: 26,
              padding: 22,
              boxShadow: '0 30px 60px rgba(16,24,40,.10)',
              border: '1px solid #EEF2EE',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 15 }}>Today's plan</div>
              <div
                style={{
                  fontSize: 12,
                  color: '#66BB6A',
                  fontWeight: 700,
                  background: '#E8F5E9',
                  padding: '5px 10px',
                  borderRadius: 999,
                }}
              >
                On budget ₦2,300
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div
                style={{
                  display: 'flex',
                  gap: 12,
                  alignItems: 'center',
                  background: '#F7FAF7',
                  borderRadius: 16,
                  padding: 12,
                }}
              >
                <div
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: 14,
                    background:
                      'repeating-linear-gradient(135deg,#EEF5EE,#EEF5EE 8px,#F7FAF7 8px,#F7FAF7 16px)',
                  }}
                />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontFamily: "'Plus Jakarta Sans'", fontSize: 14 }}>Moi Moi & Pap</div>
                  <div style={{ fontSize: 12, color: '#6B7280' }}>Breakfast · 420 kcal · 18g protein</div>
                </div>
                <div style={{ fontWeight: 700, color: '#2E7D32', fontSize: 14 }}>₦650</div>
              </div>
              <div
                style={{
                  display: 'flex',
                  gap: 12,
                  alignItems: 'center',
                  background: '#F7FAF7',
                  borderRadius: 16,
                  padding: 12,
                }}
              >
                <div
                  style={{
                    width: 52,
                    height: 52,
                    borderRadius: 14,
                    background:
                      'repeating-linear-gradient(135deg,#EEF5EE,#EEF5EE 8px,#F7FAF7 8px,#F7FAF7 16px)',
                  }}
                />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontFamily: "'Plus Jakarta Sans'", fontSize: 14 }}>Jollof Rice & Beans</div>
                  <div style={{ fontSize: 12, color: '#6B7280' }}>Lunch · 610 kcal · 22g protein</div>
                </div>
                <div style={{ fontWeight: 700, color: '#2E7D32', fontSize: 14 }}>₦900</div>
              </div>
            </div>
            <div
              style={{
                marginTop: 16,
                background: 'linear-gradient(135deg,#2E7D32,#43A047)',
                borderRadius: 18,
                padding: 16,
                color: '#fff',
                display: 'flex',
                gap: 12,
                alignItems: 'center',
              }}
            >
              <div
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 12,
                  background: 'rgba(255,255,255,.18)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                }}
              >
                <SparkleIcon size={20} stroke="#fff" strokeWidth={2} />
              </div>
              <div style={{ fontSize: 13, lineHeight: 1.4 }}>
                <b style={{ fontFamily: "'Plus Jakarta Sans'" }}>AI tip:</b> You have eggs expiring soon — I added an
                egg sauce dinner to use them.
              </div>
            </div>
          </div>
          <div
            style={{
              position: 'absolute',
              top: -18,
              right: -14,
              background: '#fff',
              borderRadius: 16,
              padding: '12px 16px',
              boxShadow: '0 16px 34px rgba(16,24,40,.12)',
              animation: 'nmFloat 4s ease-in-out infinite',
            }}
          >
            <div style={{ fontSize: 11, color: '#6B7280', fontWeight: 600 }}>Nutrition score</div>
            <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 22, color: '#2E7D32' }}>
              86<span style={{ fontSize: 13, color: '#9CA3AF' }}>/100</span>
            </div>
          </div>
        </div>
      </div>

      {/* how it works */}
      <div id="how" style={{ maxWidth: 1100, margin: '70px auto 0', padding: '0 28px', textAlign: 'center' }}>
        <div style={{ fontWeight: 700, color: '#66BB6A', fontSize: 14, letterSpacing: '.06em', textTransform: 'uppercase' }}>
          How it works
        </div>
        <h2 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 38, margin: '10px 0 44px', letterSpacing: '-.02em' }}>
          Three steps to a week of good food
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 24, textAlign: 'left' }}>
          {[
            ['Tell us your reality', "Your budget, what's already in your pantry, your goals, and what you can actually cook with."],
            ['AI reasons it out', 'On-device AI balances nutrition and cost, uses what you have first, and explains every choice.'],
            ['Eat & track', 'Get a weekly timetable, a smart shopping list, and a daily coach keeping you on track.'],
          ].map(([title, body], i) => (
            <div key={title} style={{ background: '#fff', borderRadius: 20, padding: 28, border: '1px solid #EEF2EE' }}>
              <div
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 12,
                  background: '#E8F5E9',
                  color: '#2E7D32',
                  fontFamily: "'Plus Jakarta Sans'",
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 18,
                  marginBottom: 16,
                }}
              >
                {i + 1}
              </div>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 18, marginBottom: 8 }}>{title}</div>
              <p style={{ color: '#6B7280', fontSize: 15, lineHeight: 1.6, margin: 0 }}>{body}</p>
            </div>
          ))}
        </div>
      </div>

      {/* features */}
      <div id="features" style={{ maxWidth: 1100, margin: '80px auto 0', padding: '0 28px' }}>
        <div style={{ textAlign: 'center', marginBottom: 44 }}>
          <div style={{ fontWeight: 700, color: '#66BB6A', fontSize: 14, letterSpacing: '.06em', textTransform: 'uppercase' }}>
            Features
          </div>
          <h2 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 38, margin: '10px 0 0', letterSpacing: '-.02em' }}>
            Everything a hungry student needs
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>
          {FEATURES.map((f) => (
            <div key={f.title} style={{ background: '#fff', borderRadius: 20, padding: 26, border: '1px solid #EEF2EE' }}>
              <div
                style={{
                  width: 46,
                  height: 46,
                  borderRadius: 13,
                  background: '#E8F5E9',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: 16,
                }}
              >
                <f.icon stroke="#2E7D32" />
              </div>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 17, marginBottom: 7 }}>{f.title}</div>
              <p style={{ color: '#6B7280', fontSize: 14, lineHeight: 1.6, margin: 0 }}>{f.body}</p>
            </div>
          ))}
        </div>
      </div>

      {/* testimonials */}
      <div style={{ maxWidth: 1100, margin: '80px auto 0', padding: '0 28px' }}>
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <h2 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 34, margin: 0, letterSpacing: '-.02em' }}>
            Loved by students on a budget
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>
          {TESTIMONIALS.map((t) => (
            <div key={t.name} style={{ background: '#fff', borderRadius: 20, padding: 26, border: '1px solid #EEF2EE' }}>
              <p style={{ fontSize: 15, lineHeight: 1.7, color: '#374151', margin: '0 0 20px' }}>"{t.quote}"</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    background: t.color,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#fff',
                    fontFamily: "'Plus Jakarta Sans'",
                    fontWeight: 700,
                  }}
                >
                  {t.initial}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontFamily: "'Plus Jakarta Sans'", fontSize: 14 }}>{t.name}</div>
                  <div style={{ fontSize: 12, color: '#9CA3AF' }}>{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* faq */}
      <div id="faq" style={{ maxWidth: 760, margin: '80px auto 0', padding: '0 28px' }}>
        <div style={{ textAlign: 'center', marginBottom: 36 }}>
          <h2 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 34, margin: 0, letterSpacing: '-.02em' }}>
            Questions
          </h2>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {FAQS.map((q) => (
            <div key={q.q} style={{ background: '#fff', borderRadius: 16, padding: '20px 22px', border: '1px solid #EEF2EE' }}>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 16, marginBottom: 7 }}>{q.q}</div>
              <p style={{ color: '#6B7280', fontSize: 14, lineHeight: 1.6, margin: 0 }}>{q.a}</p>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ maxWidth: 1100, margin: '80px auto 0', padding: '0 28px 40px' }}>
        <div
          style={{
            background: 'linear-gradient(135deg,#2E7D32,#43A047)',
            borderRadius: 28,
            padding: 56,
            textAlign: 'center',
            color: '#fff',
          }}
        >
          <h2 style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 38, margin: '0 0 14px', letterSpacing: '-.02em' }}>
            Eat better this week — for less.
          </h2>
          <p style={{ fontSize: 17, opacity: 0.9, margin: '0 0 28px' }}>
            Set up your first plan in under two minutes. No card needed.
          </p>
          <button
            onClick={goSignup}
            style={{
              border: 'none',
              background: '#fff',
              color: '#2E7D32',
              fontFamily: "'Plus Jakarta Sans'",
              fontWeight: 800,
              fontSize: 16,
              padding: '16px 32px',
              borderRadius: 14,
              cursor: 'pointer',
            }}
          >
            Get started free
          </button>
        </div>
      </div>

      {/* footer */}
      <div
        style={{
          borderTop: '1px solid #E7EEE7',
          padding: '30px 28px',
          maxWidth: 1200,
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          color: '#9CA3AF',
          fontSize: 13,
        }}
      >
        <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, color: '#1F2937' }}>
          NutriMate<span style={{ color: '#2E7D32' }}> AI</span>
        </div>
        <div>© 2026 NutriMate AI · Made for students</div>
      </div>
    </div>
  );
}
