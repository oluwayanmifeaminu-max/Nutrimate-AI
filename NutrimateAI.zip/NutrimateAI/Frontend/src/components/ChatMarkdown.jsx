import ReactMarkdown from 'react-markdown';

const components = {
  p: ({ children }) => <p style={{ margin: '0 0 8px' }}>{children}</p>,
  ul: ({ children }) => <ul style={{ margin: '0 0 8px', paddingLeft: 18 }}>{children}</ul>,
  ol: ({ children }) => <ol style={{ margin: '0 0 8px', paddingLeft: 18 }}>{children}</ol>,
  li: ({ children }) => <li style={{ marginBottom: 2 }}>{children}</li>,
  strong: ({ children }) => <b style={{ fontFamily: "'Plus Jakarta Sans'" }}>{children}</b>,
  a: ({ children, href }) => (
    <a href={href} target="_blank" rel="noreferrer" style={{ color: 'inherit', textDecoration: 'underline' }}>
      {children}
    </a>
  ),
};

export default function ChatMarkdown({ text }) {
  return (
    <div style={{ fontSize: 14, lineHeight: 1.55, marginBottom: -8 }}>
      <ReactMarkdown components={components}>{text}</ReactMarkdown>
    </div>
  );
}
