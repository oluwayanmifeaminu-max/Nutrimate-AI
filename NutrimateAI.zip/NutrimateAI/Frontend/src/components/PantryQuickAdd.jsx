import { useEffect, useState } from 'react';
import { useAppState } from '../state/AppState.jsx';
import { fetchIngredientNames } from '../api.js';

export default function PantryQuickAdd({ compact = false }) {
  const { addPantryItem } = useAppState();
  const [value, setValue] = useState('');
  const [knownIngredients, setKnownIngredients] = useState([]);

  useEffect(() => {
    fetchIngredientNames().then(setKnownIngredients).catch(() => {});
  }, []);

  const submit = (e) => {
    e.preventDefault();
    if (!value.trim()) return;
    addPantryItem(value);
    setValue('');
  };

  return (
    <form onSubmit={submit} style={{ display: 'flex', gap: 8 }}>
      <input
        list="known-ingredients"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="e.g. Eggs"
        style={{
          flex: 1,
          padding: compact ? '9px 12px' : '11px 14px',
          border: '1.5px solid #E3EDE3',
          borderRadius: 10,
          fontSize: compact ? 13 : 14,
          fontFamily: 'Inter',
        }}
      />
      <datalist id="known-ingredients">
        {knownIngredients.map((name) => (
          <option key={name} value={name} />
        ))}
      </datalist>
      <button
        type="submit"
        style={{
          border: 'none',
          background: '#2E7D32',
          color: '#fff',
          fontFamily: "'Plus Jakarta Sans'",
          fontWeight: 700,
          fontSize: compact ? 13 : 14,
          padding: compact ? '9px 14px' : '11px 18px',
          borderRadius: 10,
          cursor: 'pointer',
          whiteSpace: 'nowrap',
        }}
      >
        + Add
      </button>
    </form>
  );
}
