import Icon from './Icon.jsx';

export function LeafLogoIcon(props) {
  return (
    <Icon {...props}>
      <path d="M12 21c-5-3-8-7-8-11a5 5 0 0 1 8-2 5 5 0 0 1 8 2c0 4-3 8-8 11Z" />
      <path d="M12 8v6" />
    </Icon>
  );
}

export function LeafIcon(props) {
  return (
    <Icon {...props}>
      <path d="M12 21c-5-3-8-7-8-11a5 5 0 0 1 8-2 5 5 0 0 1 8 2c0 4-3 8-8 11Z" />
    </Icon>
  );
}

export function SparkleIcon(props) {
  return (
    <Icon {...props}>
      <path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15l-1.9-4.1L5.5 9l4.6-1.4L12 3Z" />
    </Icon>
  );
}

export function SparkleBurstIcon(props) {
  return (
    <Icon {...props}>
      <path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15l-1.9-4.1L5.5 9l4.6-1.4L12 3Z" />
      <path d="M5 19l.8 2M19 18l-.8 2" />
    </Icon>
  );
}

export function BoxIcon(props) {
  return (
    <Icon {...props}>
      <path d="M3 8l9-5 9 5-9 5-9-5Z" />
      <path d="M3 8v8l9 5 9-5V8" />
    </Icon>
  );
}

export function CoinIcon(props) {
  return (
    <Icon {...props}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v10M9 10h4a2 2 0 0 1 0 4H9" />
    </Icon>
  );
}

export function InfoIcon(props) {
  return (
    <Icon {...props}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 8h.01M11 12h1v4h1" />
    </Icon>
  );
}

export function CalendarIcon(props) {
  return (
    <Icon {...props}>
      <rect x="3" y="4" width="18" height="17" rx="2" />
      <path d="M3 9h18M8 2v4M16 2v4" />
    </Icon>
  );
}

export function CartIcon(props) {
  return (
    <Icon {...props}>
      <circle cx="9" cy="20" r="1.4" />
      <circle cx="18" cy="20" r="1.4" />
      <path d="M2 3h3l2.5 13h11L21 7H6" />
    </Icon>
  );
}

export function WifiOffIcon(props) {
  return (
    <Icon {...props}>
      <path d="M12 20a2 2 0 0 0 0-4 2 2 0 0 0 0 4Z" />
      <path d="M5 12a10 10 0 0 1 14 0M8.5 15.5a5 5 0 0 1 7 0" />
    </Icon>
  );
}

export function ChatBubbleIcon(props) {
  return (
    <Icon {...props}>
      <path d="M21 12a8 8 0 0 1-11.5 7.2L3 21l1.8-6.5A8 8 0 1 1 21 12Z" />
    </Icon>
  );
}

export function CheckIcon(props) {
  return (
    <Icon {...props}>
      <path d="M20 6 9 17l-5-5" />
    </Icon>
  );
}

export function SearchIcon(props) {
  return (
    <Icon {...props}>
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-4-4" />
    </Icon>
  );
}

export function BellIcon(props) {
  return (
    <Icon {...props}>
      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
      <path d="M10 21a2 2 0 0 0 4 0" />
    </Icon>
  );
}

export function DotsIcon(props) {
  return (
    <Icon {...props}>
      <circle cx="12" cy="12" r="1.5" />
      <circle cx="12" cy="5" r="1.5" />
      <circle cx="12" cy="19" r="1.5" />
    </Icon>
  );
}

export function SendIcon(props) {
  return (
    <Icon {...props}>
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </Icon>
  );
}

