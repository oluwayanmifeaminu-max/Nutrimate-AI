import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppState, naira, REASON_MSGS } from '../state/AppState.jsx';
import { CheckIcon } from './Icons.jsx';
import PantryQuickAdd from './PantryQuickAdd.jsx';
import { DURATION_OPTIONS, DIET_OPTIONS, ALLERGY_OPTIONS, MEAL_SLOTS, COOK_TIME_OPTIONS } from '../data.js';

const pillBase = { padding: '10px 16px', borderRadius: 999, fontFamily: "'Plus Jakarta Sans'", fontWeight: 600, fontSize: 13, cursor: 'pointer', border: 'none' };
const pillStyle = (sel) => ({
  ...pillBase,
  border: sel ? '1.5px solid #2E7D32' : '1.5px solid #E3EDE3',
  background: sel ? '#E8F5E9' : '#fff',
  color: sel ? '#2E7D32' : '#374151',
});
const sectionLabel = { fontWeight: 700, fontFamily: "'Plus Jakarta Sans'", fontSize: 13, marginBottom: 8 };

function AddMoreTag({ onAdd, placeholder }) {
  const [value, setValue] = useState('');
  const submit = (e) => {
    e.preventDefault();
    if (!value.trim()) return;
    onAdd(value.trim());
    setValue('');
  };
  return (
    <form onSubmit={submit} style={{ display: 'inline-flex', gap: 6 }}>
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={placeholder}
        style={{ padding: '8px 10px', border: '1.5px dashed #CBD5C9', borderRadius: 999, fontSize: 13, width: 120 }}
      />
      <button type="submit" style={{ ...pillBase, border: '1.5px dashed #CBD5C9', background: '#fff', color: '#6B7280' }}>
        +
      </button>
    </form>
  );
}

export default function MealPlanCard() {
  const navigate = useNavigate();
  const { state, setBudget, setDuration, setSlotCookTime, toggle, startGen } = useAppState();
  const { budget, duration, slotCookTime, diet, allergy, gen, genStep, generatedPlan, genError, pantry } = state;

  return (
    <div style={{ background: '#fff', borderRadius: 20, border: '1px solid #EEF2EE', padding: 22, maxWidth: 640 }}>
      <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 18, marginBottom: 4 }}>Create a meal plan</div>
      <p style={{ color: '#6B7280', fontSize: 13, margin: '0 0 18px' }}>Confirm your details and let the AI build a balanced, affordable plan.</p>

      {gen === 'idle' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <div>
            <div style={sectionLabel}>Weekly budget</div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
              <span style={{ fontSize: 12, color: '#6B7280' }}>Slide to adjust</span>
              <span style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 19, color: '#2E7D32' }}>{naira(budget)}</span>
            </div>
            <input
              type="range"
              min={3000}
              max={30000}
              step={500}
              value={budget}
              onChange={(e) => setBudget(parseInt(e.target.value, 10))}
              style={{ width: '100%', accentColor: '#2E7D32' }}
            />
          </div>

          <div>
            <div style={sectionLabel}>Duration (max 1 week)</div>
            <div style={{ display: 'flex', gap: 10 }}>
              {DURATION_OPTIONS.map((d) => (
                <button key={d} onClick={() => setDuration(d)} style={{ ...pillStyle(duration === d), flex: 1, textAlign: 'center' }}>
                  {d}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div style={sectionLabel}>Cook time per meal</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {MEAL_SLOTS.map((slot) => (
                <div key={slot} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: 13, color: '#374151', width: 70, flexShrink: 0 }}>{slot}</span>
                  <div style={{ display: 'flex', gap: 6, flex: 1 }}>
                    {COOK_TIME_OPTIONS.map((o) => (
                      <button
                        key={o.label}
                        title={o.desc}
                        onClick={() => setSlotCookTime(slot, o.label)}
                        style={{ ...pillStyle(slotCookTime[slot] === o.label), flex: 1, textAlign: 'center', padding: '8px 10px', fontSize: 12 }}
                      >
                        {o.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div style={sectionLabel}>Preferences</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
              {DIET_OPTIONS.map((d) => (
                <button key={d} onClick={() => toggle('diet', d)} style={pillStyle(diet.includes(d))}>
                  {d}
                </button>
              ))}
              {diet.filter((d) => !DIET_OPTIONS.includes(d)).map((d) => (
                <button key={d} onClick={() => toggle('diet', d)} style={pillStyle(true)}>
                  {d}
                </button>
              ))}
              <AddMoreTag placeholder="Add more" onAdd={(v) => toggle('diet', v)} />
            </div>
          </div>

          <div>
            <div style={sectionLabel}>Allergies</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
              {ALLERGY_OPTIONS.map((a) => (
                <button key={a} onClick={() => toggle('allergy', a)} style={pillStyle(allergy.includes(a))}>
                  {a}
                </button>
              ))}
              {allergy.filter((a) => !ALLERGY_OPTIONS.includes(a)).map((a) => (
                <button key={a} onClick={() => toggle('allergy', a)} style={pillStyle(true)}>
                  {a}
                </button>
              ))}
              <AddMoreTag placeholder="Add more" onAdd={(v) => toggle('allergy', v)} />
            </div>
          </div>

          <div>
            <div style={sectionLabel}>Your pantry</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 10 }}>
              {pantry.length === 0 ? (
                <span style={{ fontSize: 13, color: '#9CA3AF' }}>Nothing added yet — the plan will assume you're buying everything.</span>
              ) : (
                pantry.map((p) => (
                  <span
                    key={p.name}
                    style={{ background: '#E8F5E9', color: '#2E7D32', fontWeight: 600, fontSize: 13, padding: '7px 13px', borderRadius: 999 }}
                  >
                    {p.name}
                  </span>
                ))
              )}
            </div>
            <PantryQuickAdd compact />
          </div>

          <button
            onClick={startGen}
            style={{
              border: 'none',
              background: '#2E7D32',
              color: '#fff',
              fontFamily: "'Plus Jakarta Sans'",
              fontWeight: 700,
              fontSize: 15,
              padding: 14,
              borderRadius: 13,
              cursor: 'pointer',
              boxShadow: '0 8px 20px rgba(46,125,50,.25)',
            }}
          >
            ✨ Generate my plan
          </button>
        </div>
      )}

      {gen === 'thinking' && (
        <div>
          <div style={{ textAlign: 'center', marginBottom: 22 }}>
            <div
              style={{
                width: 52,
                height: 52,
                borderRadius: '50%',
                border: '4px solid #E8F5E9',
                borderTopColor: '#2E7D32',
                margin: '0 auto',
                animation: 'nmSpin 1s linear infinite',
              }}
            />
            <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 16, marginTop: 14 }}>Thinking…</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 320, margin: '0 auto' }}>
            {REASON_MSGS.map((text, i) => {
              const done = i < genStep;
              const active = i === genStep;
              return (
                <div key={text} style={{ display: 'flex', alignItems: 'center', gap: 10, opacity: done || active ? 1 : 0.4 }}>
                  <div
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: '50%',
                      flexShrink: 0,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      background: done ? '#2E7D32' : active ? '#fff' : '#E8F5E9',
                      border: active && !done ? '3px solid #66BB6A' : 'none',
                      animation: active && !done ? 'nmPulse 1s ease-in-out infinite' : 'none',
                    }}
                  >
                    {done && <CheckIcon size={11} stroke="#fff" strokeWidth={3} />}
                  </div>
                  <span style={{ fontSize: 13, fontWeight: 600, color: done ? '#2E7D32' : active ? '#1F2937' : '#9CA3AF' }}>{text}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {gen === 'done' && generatedPlan && (
        <div style={{ animation: 'nmFade .5s ease' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
            <div style={{ width: 38, height: 38, borderRadius: '50%', background: '#E8F5E9', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <CheckIcon size={19} stroke="#2E7D32" strokeWidth={2.6} />
            </div>
            <div>
              <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 16 }}>Your plan is ready!</div>
              <div style={{ fontSize: 12, color: '#6B7280' }}>
                {generatedPlan.days.reduce((n, d) => n + d.slots.length, 0)} meals · {naira(generatedPlan.total_cost)} total
                {generatedPlan.within_budget ? ' · within budget' : ' · over budget'}
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16 }}>
            {generatedPlan.days[0]?.slots.map((m) => (
              <div key={m.slot} style={{ display: 'flex', gap: 12, alignItems: 'center', background: '#F7FAF7', borderRadius: 14, padding: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: 'repeating-linear-gradient(135deg,#EAF3EA,#EAF3EA 8px,#F7FAF7 8px,#F7FAF7 16px)' }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontFamily: "'Plus Jakarta Sans'", fontSize: 13 }}>{m.name}</div>
                  <div style={{ fontSize: 12, color: '#6B7280' }}>{m.slot} · {m.kcal} kcal</div>
                </div>
                <div style={{ fontWeight: 700, color: '#2E7D32', fontSize: 13 }}>{naira(m.estimated_cost)}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={() => navigate('/app/timetable')}
              style={{ flex: 1, border: 'none', background: '#2E7D32', color: '#fff', fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, padding: 12, borderRadius: 12, cursor: 'pointer', fontSize: 13 }}
            >
              View full timetable →
            </button>
            <button
              onClick={() => navigate('/app/shopping')}
              style={{ flex: 1, border: '1.5px solid #E3EDE3', background: '#fff', color: '#1F2937', fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, padding: 12, borderRadius: 12, cursor: 'pointer', fontSize: 13 }}
            >
              View shopping list
            </button>
          </div>
        </div>
      )}

      {gen === 'error' && (
        <div style={{ textAlign: 'center', padding: '12px 0' }}>
          <div style={{ width: 44, height: 44, borderRadius: '50%', background: '#FDECEC', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
            <span style={{ color: '#EF5350', fontSize: 20, fontWeight: 800 }}>!</span>
          </div>
          <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 15, marginBottom: 6 }}>Couldn't generate a plan</div>
          <p style={{ color: '#6B7280', fontSize: 13, margin: '0 0 18px' }}>{genError || 'Something went wrong talking to NutriMate.'}</p>
          <button
            onClick={startGen}
            style={{ border: 'none', background: '#2E7D32', color: '#fff', fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, padding: '10px 20px', borderRadius: 12, cursor: 'pointer', fontSize: 13 }}
          >
            Try again
          </button>
        </div>
      )}
    </div>
  );
}
