const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const detail = await res.json().catch(() => ({}));
    throw new Error(detail.detail || `Request to ${path} failed with ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

function postJSON(path, body) {
  return request(path, { method: 'POST', body: JSON.stringify(body) });
}

export function chatWithAgent({ message, history, pantry }) {
  return postJSON('/api/chat', { message, history, pantry });
}

export function generateMealPlan({ budget, duration, slotCookTime, preference, allergy, pantry }) {
  return postJSON('/api/meal-plan', {
    budget,
    duration,
    slot_cook_time: slotCookTime,
    preference,
    allergy,
    pantry,
  });
}

export function fetchPantry() {
  return request('/api/pantry');
}

export async function fetchIngredientNames() {
  const ingredients = await request('/api/ingredients');
  return ingredients.map((i) => i.name);
}

export function addPantryItemApi(name) {
  return postJSON('/api/pantry', { name });
}

export function removePantryItemApi(name) {
  return request(`/api/pantry/${encodeURIComponent(name)}`, { method: 'DELETE' });
}
