import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { LeafLogoIcon, SearchIcon, BellIcon, SparkleIcon } from '../components/Icons.jsx';
import { useAppState } from '../state/AppState.jsx';
import { NAV_DEFS } from '../data.js';

const navBase = {
  position: 'relative',
  display: 'flex',
  alignItems: 'center',
  gap: 12,
  padding: '11px 13px',
  borderRadius: 12,
  border: 'none',
  background: 'transparent',
  cursor: 'pointer',
  width: '100%',
  textAlign: 'left',
  fontFamily: "'Plus Jakarta Sans'",
  fontWeight: 600,
  fontSize: 14,
  color: '#374151',
  textDecoration: 'none',
};

export default function AppLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { state } = useAppState();
  const isChat = location.pathname === '/app/chat';
  const displayName = state.name.trim() || 'Guest';
  const avatarLetter = displayName.charAt(0).toUpperCase();

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      {/* sidebar */}
      <div
        style={{
          width: 248,
          background: '#fff',
          borderRight: '1px solid #E7EEE7',
          padding: '22px 16px',
          display: 'flex',
          flexDirection: 'column',
          position: 'sticky',
          top: 0,
          height: '100vh',
          flexShrink: 0,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 8px 22px' }}>
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: 11,
              background: 'linear-gradient(135deg,#2E7D32,#66BB6A)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <LeafLogoIcon size={19} stroke="#fff" strokeWidth={2.2} />
          </div>
          <span style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 800, fontSize: 18 }}>
            NutriMate<span style={{ color: '#2E7D32' }}> AI</span>
          </span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {NAV_DEFS.map((n) => (
            <NavLink
              key={n.key}
              to={`/app/${n.key}`}
              style={({ isActive }) => ({
                ...navBase,
                ...(isActive ? { background: '#E8F5E9', color: '#2E7D32' } : {}),
              })}
            >
              {({ isActive }) => (
                <>
                  <span style={{ position: 'relative', zIndex: 1, display: 'flex', alignItems: 'center' }}>
                    <n.icon size={19} stroke={isActive ? '#2E7D32' : '#6B7280'} strokeWidth={1.9} />
                  </span>
                  <span style={{ position: 'relative', zIndex: 1 }}>{n.label}</span>
                </>
              )}
            </NavLink>
          ))}
        </div>
      </div>

      {/* main */}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        {/* topbar */}
        <div
          style={{
            height: 68,
            borderBottom: '1px solid #E7EEE7',
            background: 'rgba(247,250,247,.85)',
            backdropFilter: 'blur(8px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0 28px',
            position: 'sticky',
            top: 0,
            zIndex: 20,
          }}
        >
          <div style={{ position: 'relative', width: 340, maxWidth: '40vw' }}>
            <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }}>
              <SearchIcon size={17} stroke="#9CA3AF" strokeWidth={2} />
            </span>
            <input
              placeholder="Search meals, ingredients…"
              style={{
                width: '100%',
                padding: '11px 14px 11px 40px',
                border: '1.5px solid #E3EDE3',
                borderRadius: 12,
                fontSize: 14,
                background: '#fff',
                fontFamily: 'Inter',
              }}
            />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
            <button
              style={{
                position: 'relative',
                border: '1px solid #E3EDE3',
                background: '#fff',
                width: 40,
                height: 40,
                borderRadius: 12,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
              }}
            >
              <BellIcon size={19} stroke="#4B5563" strokeWidth={2} />
              <span
                style={{
                  position: 'absolute',
                  top: 8,
                  right: 9,
                  width: 8,
                  height: 8,
                  background: '#EF5350',
                  borderRadius: '50%',
                  border: '2px solid #fff',
                }}
              />
            </button>
            <div
              style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}
              onClick={() => navigate('/app/profile')}
            >
              <div
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: '50%',
                  background: 'linear-gradient(135deg,#66BB6A,#2E7D32)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#fff',
                  fontFamily: "'Plus Jakarta Sans'",
                  fontWeight: 700,
                }}
              >
                {avatarLetter}
              </div>
              <div style={{ lineHeight: 1.2 }}>
                <div style={{ fontFamily: "'Plus Jakarta Sans'", fontWeight: 700, fontSize: 14 }}>{displayName}</div>
                <div style={{ fontSize: 12, color: '#9CA3AF' }}>Student</div>
              </div>
            </div>
          </div>
        </div>

        <div style={{ padding: 28, flex: 1 }}>
          <Outlet />
        </div>
      </div>

      {/* floating AI assistant */}
      {!isChat && (
        <button
          onClick={() => navigate('/app/chat')}
          style={{
            position: 'fixed',
            bottom: 28,
            right: 28,
            width: 60,
            height: 60,
            borderRadius: '50%',
            border: 'none',
            background: 'linear-gradient(135deg,#2E7D32,#43A047)',
            boxShadow: '0 12px 30px rgba(46,125,50,.4)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 50,
            animation: 'nmFloat 4s ease-in-out infinite',
          }}
        >
          <SparkleIcon size={26} stroke="#fff" strokeWidth={2} />
        </button>
      )}
    </div>
  );
}
