import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { chatWithAgent, generateMealPlan, fetchPantry, addPantryItemApi, removePantryItemApi } from '../api.js';

export const REASON_MSGS = [
  'Analyzing your pantry…',
  'Balancing nutrients…',
  'Optimizing your budget…',
  'Generating meal recommendations…',
];

const initialState = {
  name: '',
  gen: 'idle',
  genStep: 0,
  genError: null,
  generatedPlan: null,
  day: 'Mon',
  budget: 12000,
  duration: '1 week',
  goals: ['Eat Healthier'],
  diet: ['High Protein', 'Halal'],
  allergy: [],
  equip: ['Gas Cooker', 'Kettle'],
  skill: 'Intermediate',
  slotCookTime: { Breakfast: 'Fast', Lunch: 'Intermediate', Dinner: 'Intermediate' },
  pantry: [],
  pantryLoading: true,
  chatInput: '',
  chatLoading: false,
  chat: [],
};

function pantryNames(s) {
  return s.pantry.map((p) => p.name);
}

function toApiHistory(chat) {
  return chat
    .filter((m) => m.type !== 'mealplan-card')
    .map((m) => ({ role: m.role === 'ai' ? 'assistant' : 'user', content: m.text }));
}

const AppStateContext = createContext(null);

export function AppStateProvider({ children }) {
  const [state, setState] = useState(initialState);
  const timerRef = useRef(null);

  useEffect(() => {
    fetchPantry()
      .then((items) => setState((s) => ({ ...s, pantry: items, pantryLoading: false })))
      .catch(() => setState((s) => ({ ...s, pantryLoading: false })));
  }, []);

  const toggle = (key, val) => {
    setState((s) => {
      const arr = s[key];
      return { ...s, [key]: arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val] };
    });
  };

  const setName = (name) => setState((s) => ({ ...s, name }));

  const ensureGreeting = () => {
    setState((s) => {
      if (s.chat.length > 0) return s;
      const greetName = s.name.trim() ? s.name.trim().split(' ')[0] : 'there';
      return {
        ...s,
        chat: [
          {
            role: 'ai',
            text: `Hey ${greetName}! I'm your NutriMate coach. Ask me what to cook, how to stretch your budget, or how to hit your goals — I work fully offline.`,
          },
        ],
      };
    });
  };

  const setBudget = (n) => setState((s) => ({ ...s, budget: n }));
  const setDuration = (duration) => setState((s) => ({ ...s, duration }));
  const setSkill = (skill) => setState((s) => ({ ...s, skill }));
  const setDay = (day) => setState((s) => ({ ...s, day }));

  const setSlotCookTime = (slot, value) =>
    setState((s) => ({ ...s, slotCookTime: { ...s.slotCookTime, [slot]: value } }));

  const addPantryItem = async (name) => {
    const trimmed = (name || '').trim();
    if (!trimmed) return;
    if (state.pantry.some((p) => p.name.toLowerCase() === trimmed.toLowerCase())) return;
    try {
      const item = await addPantryItemApi(trimmed);
      setState((s) => (s.pantry.some((p) => p.name === item.name) ? s : { ...s, pantry: [...s.pantry, item] }));
    } catch (err) {
      console.error('Failed to add pantry item:', err);
    }
  };

  const removePantryItem = async (name) => {
    try {
      await removePantryItemApi(name);
      setState((s) => ({ ...s, pantry: s.pantry.filter((p) => p.name !== name) }));
    } catch (err) {
      console.error('Failed to remove pantry item:', err);
    }
  };

  const startGen = async () => {
    clearInterval(timerRef.current);
    setState((s) => ({ ...s, gen: 'thinking', genStep: 0, genError: null }));
    // Purely a visual "reasoning" animation — advances on a timer but stops
    // at the last step and waits rather than looping, since the real
    // request underneath can take longer than this fixed animation.
    timerRef.current = setInterval(() => {
      setState((s) => {
        if (s.genStep >= REASON_MSGS.length - 1) {
          clearInterval(timerRef.current);
          return s;
        }
        return { ...s, genStep: s.genStep + 1 };
      });
    }, 1050);

    const { budget, duration, slotCookTime, diet, allergy } = state;
    try {
      const plan = await generateMealPlan({
        budget,
        duration,
        slotCookTime,
        preference: diet,
        allergy,
        pantry: pantryNames(state),
      });
      clearInterval(timerRef.current);
      setState((s) => ({ ...s, gen: 'done', generatedPlan: plan }));
    } catch (err) {
      clearInterval(timerRef.current);
      setState((s) => ({ ...s, gen: 'error', genError: err.message }));
    }
  };

  const setChatInput = (chatInput) => setState((s) => ({ ...s, chatInput }));

  const sendPrompt = async (text) => {
    const history = toApiHistory(state.chat);
    const pantry = pantryNames(state);
    setState((s) => ({ ...s, chat: [...s.chat, { role: 'user', text }], chatLoading: true }));
    try {
      const { reply } = await chatWithAgent({ message: text, history, pantry });
      setState((s) => ({ ...s, chat: [...s.chat, { role: 'ai', text: reply }], chatLoading: false }));
    } catch (err) {
      setState((s) => ({
        ...s,
        chat: [...s.chat, { role: 'ai', text: `Sorry, something went wrong reaching NutriMate: ${err.message}` }],
        chatLoading: false,
      }));
    }
  };

  const sendChat = async () => {
    const text = (state.chatInput || '').trim();
    if (!text) return;
    const history = toApiHistory(state.chat);
    const pantry = pantryNames(state);
    setState((s) => ({ ...s, chat: [...s.chat, { role: 'user', text }], chatInput: '', chatLoading: true }));
    try {
      const { reply } = await chatWithAgent({ message: text, history, pantry });
      setState((s) => ({ ...s, chat: [...s.chat, { role: 'ai', text: reply }], chatLoading: false }));
    } catch (err) {
      setState((s) => ({
        ...s,
        chat: [...s.chat, { role: 'ai', text: `Sorry, something went wrong reaching NutriMate: ${err.message}` }],
        chatLoading: false,
      }));
    }
  };

  const startMealPlanCard = () => {
    clearInterval(timerRef.current);
    setState((s) => ({
      ...s,
      gen: 'idle',
      genStep: 0,
      genError: null,
      generatedPlan: null,
      chat: [...s.chat, { role: 'user', text: 'Create a meal plan' }, { role: 'ai', type: 'mealplan-card' }],
    }));
  };

  const value = {
    state,
    toggle,
    setName,
    ensureGreeting,
    setBudget,
    setDuration,
    setSkill,
    setDay,
    setSlotCookTime,
    addPantryItem,
    removePantryItem,
    startGen,
    setChatInput,
    sendPrompt,
    sendChat,
    startMealPlanCard,
  };

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used within AppStateProvider');
  return ctx;
}

export function naira(n) {
  return '₦' + n.toLocaleString('en-NG');
}
