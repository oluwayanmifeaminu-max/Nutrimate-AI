import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture(autouse=True)
def clean_pantry():
    # tests share the same SQLite file as the dev server; keep them isolated
    # from each other and leave no residue behind either way
    from sqlmodel import select

    from app.db import get_session
    from app.db_models import PantryItemRow

    yield
    with get_session() as session:
        for row in session.exec(select(PantryItemRow).where(PantryItemRow.name.in_(["Test Ingredient", "Dup Item"]))):
            session.delete(row)
        session.commit()


def test_pantry_add_list_remove(client):
    resp = client.post("/api/pantry", json={"name": "Test Ingredient"})
    assert resp.status_code == 200
    assert resp.json()["name"] == "Test Ingredient"

    resp = client.get("/api/pantry")
    names = [item["name"] for item in resp.json()]
    assert "Test Ingredient" in names

    resp = client.delete("/api/pantry/Test Ingredient")
    assert resp.status_code == 200

    resp = client.get("/api/pantry")
    names = [item["name"] for item in resp.json()]
    assert "Test Ingredient" not in names


def test_pantry_add_is_idempotent_on_duplicate_name(client):
    client.post("/api/pantry", json={"name": "Dup Item"})
    resp = client.post("/api/pantry", json={"name": "Dup Item"})
    assert resp.status_code == 200

    resp = client.get("/api/pantry")
    names = [item["name"] for item in resp.json()]
    assert names.count("Dup Item") == 1


def test_pantry_remove_unknown_item_returns_404(client):
    resp = client.delete("/api/pantry/Definitely Not A Real Item")
    assert resp.status_code == 404
