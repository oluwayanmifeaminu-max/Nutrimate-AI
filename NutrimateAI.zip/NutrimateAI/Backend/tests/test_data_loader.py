from app.data.loader import FoodDB, cook_time_category


def test_cook_time_bands():
    assert cook_time_category(5) == "fast"
    assert cook_time_category(10) == "fast"
    assert cook_time_category(11) == "intermediate"
    assert cook_time_category(60) == "intermediate"
    assert cook_time_category(61) == "long"
    assert cook_time_category(120) == "long"


def test_loads_food_db():
    db = FoodDB()
    assert len(db.ingredients) > 0
    assert len(db.dishes) > 0
    for dish in db.dishes.values():
        for line in dish.ingredients:
            assert line.ingredient_id in db.ingredients


def test_ingredient_alias_lookup():
    db = FoodDB()
    assert db.find_ingredient_by_name("eggs") is not None
    assert db.find_ingredient_by_name("EGG") is not None
    assert db.find_ingredient_by_name("Red Oil") is not None
    assert db.find_ingredient_by_name("nonexistent-thing") is None


def test_dish_allergens_derived_from_ingredients():
    db = FoodDB()
    moi_moi = db.dishes["moi-moi"]
    assert "egg" in db.dish_allergens(moi_moi)
