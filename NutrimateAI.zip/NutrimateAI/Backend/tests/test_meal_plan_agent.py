import pytest

from app.agent.meal_plan_agent import MealPlanError, generate_meal_plan
from app.data.loader import FoodDB
from app.providers.base import ProviderResponse, ToolCall
from app.tools.get_foods import get_foods


class FakeProvider:
    """Returns a canned submit_meal_plan call immediately — no live model
    needed to test the validation/aggregation path itself."""

    def __init__(self, tool_calls_sequence):
        self._sequence = list(tool_calls_sequence)

    def chat(self, messages, tools):
        return self._sequence.pop(0)


@pytest.fixture
def db():
    return FoodDB()


def test_malformed_submit_meal_plan_raises_clear_error(db):
    bad_call = ProviderResponse(
        content=None,
        tool_calls=[ToolCall(id="1", name="submit_meal_plan", arguments={"days": [{"day": "Day 1"}]})],  # missing "slots"
    )
    provider = FakeProvider([bad_call])
    with pytest.raises(MealPlanError, match="didn't match the expected shape"):
        generate_meal_plan(
            provider, db, budget=10000, duration="3 days",
            slot_cook_time={"breakfast": "fast", "lunch": "intermediate", "dinner": "intermediate"},
            preference=[], allergy=[], pantry=[],
        )


def test_unknown_dish_id_raises_clear_error(db):
    bad_call = ProviderResponse(
        content=None,
        tool_calls=[
            ToolCall(
                id="1",
                name="submit_meal_plan",
                arguments={"days": [{"day": "Day 1", "slots": [{"slot": "breakfast", "dish_id": "not-a-real-dish"}]}]},
            )
        ],
    )
    provider = FakeProvider([bad_call])
    with pytest.raises(MealPlanError, match="unknown dish_id"):
        generate_meal_plan(
            provider, db, budget=10000, duration="3 days",
            slot_cook_time={"breakfast": "fast", "lunch": "intermediate", "dinner": "intermediate"},
            preference=[], allergy=[], pantry=[],
        )


def test_valid_submit_meal_plan_produces_priced_plan(db):
    good_call = ProviderResponse(
        content=None,
        tool_calls=[
            ToolCall(
                id="1",
                name="submit_meal_plan",
                arguments={"days": [{"day": "Day 1", "slots": [{"slot": "breakfast", "dish_id": "bread-and-fried-egg"}]}]},
            )
        ],
    )
    provider = FakeProvider([good_call])
    result = generate_meal_plan(
        provider, db, budget=10000, duration="3 days",
        slot_cook_time={"breakfast": "fast", "lunch": "intermediate", "dinner": "intermediate"},
        preference=[], allergy=[], pantry=[],
    )
    assert result["days"][0]["slots"][0]["name"] == "Bread and Fried Egg"
    assert result["total_cost"] > 0
    assert result["within_budget"] is True


def test_over_budget_selection_gets_swapped_to_cheapest(db):
    dinner_candidates = get_foods(db, slot="dinner", cook_time_category="intermediate", source={"type": "pantry", "items": []})
    cheapest = min(dinner_candidates, key=lambda c: c["estimated_cost"])
    most_expensive = max(dinner_candidates, key=lambda c: c["estimated_cost"])
    assert cheapest["id"] != most_expensive["id"]  # otherwise this test can't distinguish a swap happening

    budget = cheapest["estimated_cost"] + 1  # fits the cheapest, not the expensive pick
    bad_call = ProviderResponse(
        content=None,
        tool_calls=[
            ToolCall(
                id="1",
                name="submit_meal_plan",
                arguments={"days": [{"day": "Day 1", "slots": [{"slot": "dinner", "dish_id": most_expensive["id"]}]}]},
            )
        ],
    )
    provider = FakeProvider([bad_call])
    result = generate_meal_plan(
        provider, db, budget=budget, duration="3 days",
        slot_cook_time={"breakfast": "fast", "lunch": "intermediate", "dinner": "intermediate"},
        preference=[], allergy=[], pantry=[],
    )
    assert result["days"][0]["slots"][0]["dish_id"] == cheapest["id"]
    assert result["total_cost"] <= budget
    assert result["within_budget"] is True


def test_genuinely_infeasible_budget_returns_cheapest_possible_honestly(db):
    breakfast_candidates = get_foods(db, slot="breakfast", cook_time_category="fast", source={"type": "pantry", "items": []})
    cheapest = min(breakfast_candidates, key=lambda c: c["estimated_cost"])
    most_expensive = max(breakfast_candidates, key=lambda c: c["estimated_cost"])

    impossible_budget = 1  # below even the cheapest option
    bad_call = ProviderResponse(
        content=None,
        tool_calls=[
            ToolCall(
                id="1",
                name="submit_meal_plan",
                arguments={"days": [{"day": "Day 1", "slots": [{"slot": "breakfast", "dish_id": most_expensive["id"]}]}]},
            )
        ],
    )
    provider = FakeProvider([bad_call])
    result = generate_meal_plan(
        provider, db, budget=impossible_budget, duration="3 days",
        slot_cook_time={"breakfast": "fast", "lunch": "intermediate", "dinner": "intermediate"},
        preference=[], allergy=[], pantry=[],
    )
    # can't fit the budget no matter what, but it should still land on the
    # cheapest achievable option rather than leaving the expensive one in place
    assert result["days"][0]["slots"][0]["dish_id"] == cheapest["id"]
    assert result["within_budget"] is False
