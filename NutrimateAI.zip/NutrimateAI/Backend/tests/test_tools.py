import pytest

from app.data.loader import FoodDB
from app.tools.calculator import CalculatorError, calculator
from app.tools.get_foods import get_foods
from app.tools.get_recipe import get_recipe
from app.tools.search_ingredient import search_ingredient
from app.tools.shopping_list import price_items_by_name, price_shopping_list


@pytest.fixture
def db():
    return FoodDB()


def test_calculator_basic():
    assert calculator("12000 - 4850") == 7150
    assert calculator("2 * (3 + 4)") == 14
    assert calculator("10 / 4") == 2.5


def test_calculator_rejects_unsafe_input():
    with pytest.raises(CalculatorError):
        calculator("__import__('os').system('echo hi')")
    with pytest.raises(CalculatorError):
        calculator("open('/etc/passwd')")


def test_get_foods_filters_by_slot_and_cook_time(db):
    results = get_foods(db, slot="breakfast", cook_time_category="fast", source={"type": "pantry", "items": []})
    assert all("breakfast" in db.dishes[r["id"]].slots for r in results)
    assert all(r["cook_time_mins"] <= 10 for r in results)


def test_get_foods_pantry_reduces_cost(db):
    no_pantry = get_foods(db, slot="breakfast", cook_time_category="intermediate", source={"type": "pantry", "items": []})
    with_pantry = get_foods(
        db, slot="breakfast", cook_time_category="intermediate", source={"type": "pantry", "items": ["Beans", "Eggs", "Onions", "Pepper", "Palm Oil"]}
    )
    moi_moi_no_pantry = next(r for r in no_pantry if r["id"] == "moi-moi")
    moi_moi_with_pantry = next(r for r in with_pantry if r["id"] == "moi-moi")
    assert moi_moi_with_pantry["estimated_cost"] < moi_moi_no_pantry["estimated_cost"]
    assert moi_moi_with_pantry["missing_items"] != moi_moi_no_pantry["missing_items"]


def test_get_foods_excludes_allergens(db):
    results = get_foods(
        db, slot="breakfast", cook_time_category="intermediate", source={"type": "pantry", "items": []}, allergy=["Egg"]
    )
    assert all("egg" not in db.dish_allergens(db.dishes[r["id"]]) for r in results)


def test_get_foods_filters_by_preference(db):
    results = get_foods(
        db, slot="lunch", cook_time_category="intermediate", source={"type": "pantry", "items": []}, preference=["Vegan"]
    )
    assert all("vegan" in db.dishes[r["id"]].diet_tags for r in results)


def test_get_recipe_resolves_by_name(db):
    recipe = get_recipe(db, "Rice and Beans")
    assert recipe is not None
    assert recipe["ingredients"]
    assert recipe["steps"]


def test_get_recipe_unknown_dish_returns_none(db):
    assert get_recipe(db, "Nonexistent Dish 12345") is None


def test_price_shopping_list_dedupes_and_sums_across_dishes(db):
    # two dishes both needing rice — should collapse to ONE rice line at the
    # summed quantity, not double it at full per-dish price
    jollof = get_foods(db, slot="lunch", cook_time_category="intermediate", source={"type": "pantry", "items": []})
    fried_rice = get_foods(db, slot="dinner", cook_time_category="intermediate", source={"type": "pantry", "items": []})
    jollof_missing = next(r for r in jollof if r["id"] == "jollof-rice-with-chicken")["missing_items"]
    fried_rice_missing = next(r for r in fried_rice if r["id"] == "nigerian-fried-rice")["missing_items"]

    result = price_shopping_list(db, [jollof_missing, fried_rice_missing])
    rice_lines = [line for line in result["items"] if line["name"] == "Rice"]
    assert len(rice_lines) == 1
    expected_qty = next(li["quantity"] for li in jollof_missing if li["name"] == "Rice") + next(
        li["quantity"] for li in fried_rice_missing if li["name"] == "Rice"
    )
    assert rice_lines[0]["quantity"] == pytest.approx(expected_qty)


def test_price_items_by_name_handles_unknown_ingredient(db):
    result = price_items_by_name(db, [{"name": "Eggs", "quantity": 2}, {"name": "Unobtainium", "quantity": 1}])
    assert result["items"][0]["subtotal"] is not None
    assert result["items"][1]["note"] == "unknown ingredient"


def test_search_ingredient_found(db):
    result = search_ingredient(db, "Eggs")
    assert result["found"] is True
    assert result["name"] == "Egg"
    assert "price_per_unit" in result


def test_search_ingredient_not_found_does_not_imply_unhealthy(db):
    result = search_ingredient(db, "Kiwi")
    assert result["found"] is False
    # the whole point: the note must explicitly disclaim any nutrition/reality judgment
    assert "real or nutritious" in result["note"]
