import pytest

from app.data.loader import FoodDB
from app.tools.dispatch import execute_tool


@pytest.fixture
def db():
    return FoodDB()


def test_get_foods_missing_required_field_returns_clear_error(db):
    # no slot/cook_time_category at all — this is the exact shape the model
    # was observed sending before the prompt fix (empty source={})
    result = execute_tool(db, "get_foods", {"source": {}})
    assert "error" in result
    assert "get_foods" in result["error"]


def test_get_foods_invalid_enum_value_returns_clear_error(db):
    result = execute_tool(db, "get_foods", {"slot": "brunch", "cook_time_category": "fast", "source": {"type": "pantry", "items": []}})
    assert "error" in result


def test_get_foods_valid_args_executes_normally(db):
    result = execute_tool(
        db, "get_foods", {"slot": "breakfast", "cook_time_category": "fast", "source": {"type": "pantry", "items": []}}
    )
    assert "results" in result
    assert isinstance(result["results"], list)


def test_get_recipe_missing_food_returns_clear_error(db):
    result = execute_tool(db, "get_recipe", {})
    assert "error" in result


def test_calculator_missing_expression_returns_clear_error(db):
    result = execute_tool(db, "calculator", {})
    assert "error" in result


def test_price_shopping_list_malformed_items_returns_clear_error(db):
    result = execute_tool(db, "price_shopping_list", {"items": [{"quantity": 2}]})  # missing required "name"
    assert "error" in result


def test_search_ingredient_missing_name_returns_clear_error(db):
    result = execute_tool(db, "search_ingredient", {})
    assert "error" in result


def test_search_ingredient_dispatch_roundtrip(db):
    result = execute_tool(db, "search_ingredient", {"name": "Rice"})
    assert result["found"] is True
