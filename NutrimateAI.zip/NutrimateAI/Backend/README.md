# NutriMate AI — Backend

FastAPI backend for the NutriMate AI meal planner. Serves a Gemma 4-powered
agent ("NutriMate Coach") that plans meals and answers nutrition questions
over native tool/function calls against a real Nigerian food database.

See the [root README](../README.md) for the full project overview, screenshots,
and how Gemma is used. This file covers backend-specific setup and internals.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env — pick a model provider (see below)

uvicorn app.main:app --reload
```

Runs at `http://localhost:8000`. Interactive API docs at `/docs`. The SQLite
database is created and auto-seeded from the researched dataset on first run.

## Choosing a model

Edit `.env` before running. Three supported setups:

| `.env` | Notes |
|---|---|
| `MODEL_PROVIDER=ollama`<br>`MODEL_NAME=gemma4:e4b` | Fully local/offline. Needs the model pulled (`ollama pull gemma4:e4b`) and enough hardware to run it — smaller and faster than 31B, but weaker at reliably picking the right tool/arguments. |
| `MODEL_PROVIDER=ollama`<br>`MODEL_NAME=gemma4:31b-cloud` | Ollama Cloud. Needs `ollama signin` (or `OLLAMA_API_KEY`) and a local `ollama serve` running — the cloud call is proxied through it. This is what the project was primarily developed and tested against. |
| `MODEL_PROVIDER=openrouter`<br>`MODEL_NAME=<any model id>`<br>`OPENROUTER_API_KEY=...` | Any hosted model available on [openrouter.ai](https://openrouter.ai). |

Ollama Cloud and local Ollama share one provider implementation — same API,
different model tag. `OLLAMA_HOST` only needs to change if your Ollama
daemon isn't on the default `localhost:11434`.

## Data

`app/data/ingredients.json` and `app/data/dishes.json` are the reviewable seed
source — 78 ingredients and 53 real Nigerian dishes, researched (not hand-guessed)
including real 2026 market prices. `app/seed.py` loads them into SQLite
(`app/data/nutrimate.db`, gitignored, regenerated automatically) on first run —
idempotent, so it's safe to call on every startup. SQLite is the runtime store;
the JSON files are what you'd edit/regenerate to update the dataset.

Pantry is a separate, mutable table (`pantry_items`) with no prefill — it
starts empty and is only ever populated by the user via `/api/pantry`.

## Architecture

- `app/providers/` — model provider abstraction (Ollama, OpenRouter) behind
  one `chat(messages, tools) -> ProviderResponse` interface.
- `app/tools/` — the tools Gemma calls: `get_foods`, `get_recipe`,
  `search_ingredient` (checks local pantry/pricing tracking — explicitly
  does not gate nutrition judgments), `price_shopping_list` (ad hoc pricing),
  plus the internal `price_shopping_list()` aggregator called automatically
  once a full plan is assembled — deliberately *not* an LLM step, since it's
  pure dedupe/sum/price arithmetic with no judgment call in it. Every tool's
  arguments are validated through a Pydantic model (`args_models.py`) before
  they touch application logic.
- `app/agent/` — `run_agent_loop` (the shared tool-calling loop),
  `chat_agent.py` (freeform Q&A), `meal_plan_agent.py` (structured weekly
  planning — candidates are pre-fetched deterministically in Python and
  handed to the model already priced; the model finishes by calling
  `submit_meal_plan` rather than free text; `_enforce_budget` then
  deterministically swaps any over-budget picks for cheaper candidates from
  the same pool until the total fits or every slot is already at its true
  minimum).
- `app/db_models.py` + `app/db.py` + `app/seed.py` — SQLite-backed food DB
  and pantry storage (see "Data" above).
- `app/main.py` — FastAPI routes.

## Endpoints

- `POST /api/chat` — `{"message", "history": [{"role","content"}], "pantry": [str]}` → `{"reply": str}`
- `POST /api/meal-plan` — `{"budget", "duration", "slot_cook_time": {"breakfast","lunch","dinner"}, "preference": [], "allergy": [], "pantry": []}` → assembled days + priced shopping list, guaranteed within budget unless mathematically infeasible
- `GET /api/pantry`, `POST /api/pantry` (`{"name"}`), `DELETE /api/pantry/{name}`
- `GET /health`, `GET /api/ingredients`, `GET /api/dishes`

## Tests

```bash
pytest
```

32 tests covering tool logic, argument validation, budget enforcement, and
the pantry API — no live model needed. The agent loop itself requires a real
provider to exercise end-to-end (see the root README's Quickstart).
