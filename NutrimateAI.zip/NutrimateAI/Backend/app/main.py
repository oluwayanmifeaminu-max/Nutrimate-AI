from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import select

from app.agent.chat_agent import run_chat_agent
from app.agent.loop import AgentExhaustedError
from app.agent.meal_plan_agent import MealPlanError, generate_meal_plan
from app.data.loader import get_db
from app.db import get_session
from app.db_models import PantryItemRow
from app.models import ChatRequest, ChatResponse, MealPlanRequest, PantryAddRequest, PantryItemOut
from app.providers import get_provider

app = FastAPI(title="NutriMate AI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    db = get_db()
    return {"status": "ok", "dishes": len(db.dishes), "ingredients": len(db.ingredients)}


@app.get("/api/ingredients")
def list_ingredients():
    db = get_db()
    return list(db.ingredients.values())


@app.get("/api/dishes")
def list_dishes():
    db = get_db()
    return list(db.dishes.values())


@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    db = get_db()
    provider = get_provider()
    history = [m.model_dump() for m in req.history]
    try:
        reply = run_chat_agent(provider, db, req.message, history, req.pantry)
    except AgentExhaustedError as e:
        raise HTTPException(status_code=502, detail=str(e)) from e
    return ChatResponse(reply=reply)


@app.get("/api/pantry", response_model=list[PantryItemOut])
def list_pantry():
    with get_session() as session:
        rows = session.exec(select(PantryItemRow)).all()
        return [PantryItemOut(name=r.name, qty=r.qty, cat=r.cat, tag=r.tag, level=r.level) for r in rows]


@app.post("/api/pantry", response_model=PantryItemOut)
def add_pantry_item(req: PantryAddRequest):
    name = req.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="name must not be empty")
    with get_session() as session:
        existing = session.exec(select(PantryItemRow).where(PantryItemRow.name == name)).first()
        if existing:
            return PantryItemOut(name=existing.name, qty=existing.qty, cat=existing.cat, tag=existing.tag, level=existing.level)
        row = PantryItemRow(name=name)
        session.add(row)
        session.commit()
        return PantryItemOut(name=row.name, qty=row.qty, cat=row.cat, tag=row.tag, level=row.level)


@app.delete("/api/pantry/{name}")
def remove_pantry_item(name: str):
    with get_session() as session:
        row = session.exec(select(PantryItemRow).where(PantryItemRow.name == name)).first()
        if row is None:
            raise HTTPException(status_code=404, detail=f"No pantry item named {name!r}")
        session.delete(row)
        session.commit()
    return {"ok": True}


@app.post("/api/meal-plan")
def meal_plan(req: MealPlanRequest):
    db = get_db()
    provider = get_provider()
    try:
        return generate_meal_plan(
            provider,
            db,
            budget=req.budget,
            duration=req.duration,
            slot_cook_time=req.slot_cook_time,
            preference=req.preference,
            allergy=req.allergy,
            pantry=req.pantry,
        )
    except (AgentExhaustedError, MealPlanError) as e:
        raise HTTPException(status_code=502, detail=str(e)) from e
