from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # "ollama" covers both local and Ollama Cloud models (they share one API,
    # just pointed at OLLAMA_HOST; cloud vs local is decided by MODEL_NAME,
    # e.g. "gemma4:e4b" runs fully local, "gemma4:31b-cloud" is proxied to
    # Ollama Cloud by the local `ollama serve` daemon). "openrouter" is a
    # separate OpenAI-compatible provider.
    model_provider: str = "ollama"
    model_name: str = "gemma4:31b-cloud"

    ollama_host: str = "http://localhost:11434"
    ollama_api_key: str = ""

    openrouter_api_key: str = ""
    openrouter_base_url: str = "https://openrouter.ai/api/v1"

    # A meal plan legitimately needs ~3 get_foods calls (one per slot) plus a
    # few calculator checks plus submit_meal_plan itself; 8 proved too tight
    # against the full dataset's larger candidate pools, where the model did
    # a bit of redundant double-checking before converging.
    agent_max_tool_iterations: int = 14


settings = Settings()
