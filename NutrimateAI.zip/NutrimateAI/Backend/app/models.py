from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    message: str
    history: list[ChatMessage] = Field(default_factory=list)
    pantry: list[str] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str


class MealPlanRequest(BaseModel):
    budget: float
    duration: str = "1 week"
    slot_cook_time: dict[str, str] = Field(
        default_factory=lambda: {"breakfast": "fast", "lunch": "intermediate", "dinner": "intermediate"}
    )
    preference: list[str] = Field(default_factory=list)
    allergy: list[str] = Field(default_factory=list)
    pantry: list[str] = Field(default_factory=list)


class PantryItemOut(BaseModel):
    name: str
    qty: str
    cat: str
    tag: str
    level: str


class PantryAddRequest(BaseModel):
    name: str
