from __future__ import annotations

import json
from typing import Any

from app.data.loader import FoodDB
from app.providers.base import ModelProvider
from app.tools.dispatch import execute_tool


class AgentExhaustedError(RuntimeError):
    """Raised when the model doesn't converge to a final answer within the
    iteration budget — a defensive bound so a confused/small model can't
    loop forever."""


def run_agent_loop(
    provider: ModelProvider,
    db: FoodDB,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    max_iterations: int,
    terminal_tool_name: str | None = None,
) -> tuple[str | None, dict | None]:
    """Drives the tool-calling conversation to completion.

    Returns (content, None) once the model answers in plain text, or
    (None, terminal_arguments) if `terminal_tool_name` was called — that
    tool is treated as the model's final structured answer rather than
    something to execute and feed a result back for.
    """
    for _ in range(max_iterations):
        resp = provider.chat(messages, tools)

        if not resp.tool_calls:
            return resp.content, None

        if terminal_tool_name:
            terminal_call = next((tc for tc in resp.tool_calls if tc.name == terminal_tool_name), None)
            if terminal_call:
                return None, terminal_call.arguments

        messages.append(
            {
                "role": "assistant",
                "content": resp.content or "",
                "tool_calls": [
                    {"id": tc.id, "type": "function", "function": {"name": tc.name, "arguments": tc.arguments}}
                    for tc in resp.tool_calls
                ],
            }
        )
        for tc in resp.tool_calls:
            result = execute_tool(db, tc.name, tc.arguments)
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": json.dumps(result)})

    raise AgentExhaustedError(f"Model did not converge within {max_iterations} tool-call iterations")
