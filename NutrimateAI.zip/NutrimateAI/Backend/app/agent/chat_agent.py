from __future__ import annotations

from app.agent.loop import run_agent_loop
from app.agent.prompts import CHAT_SYSTEM_PROMPT
from app.config import settings
from app.data.loader import FoodDB
from app.providers.base import ModelProvider
from app.tools.schemas import CHAT_TOOLS


def run_chat_agent(
    provider: ModelProvider,
    db: FoodDB,
    message: str,
    history: list[dict] | None = None,
    pantry: list[str] | None = None,
) -> str:
    system_content = CHAT_SYSTEM_PROMPT
    if pantry:
        # Passed explicitly rather than relying on the model to extract
        # ingredient mentions from free text — that was tried and silently
        # dropped items the user actually stated (source={} with nothing in
        # it), so get_foods never saw what they had on hand.
        system_content += (
            f"\n\nThe user's current pantry: {', '.join(pantry)}. "
            "When calling get_foods, pass this as source={\"type\": \"pantry\", \"items\": [...]} using this list."
        )
    messages = [{"role": "system", "content": system_content}]
    messages.extend(history or [])
    messages.append({"role": "user", "content": message})

    content, _ = run_agent_loop(provider, db, messages, CHAT_TOOLS, settings.agent_max_tool_iterations)
    return content or "Sorry, I couldn't come up with a response for that."
