from __future__ import annotations

import json
import re

from pydantic import ValidationError

from app.agent.loop import run_agent_loop
from app.agent.prompts import MEAL_PLAN_SYSTEM_PROMPT
from app.config import settings
from app.data.loader import FoodDB
from app.providers.base import ModelProvider
from app.tools.args_models import SubmitMealPlanArgs
from app.tools.get_foods import dish_cost, get_foods, resolve_have_ids
from app.tools.schemas import MEAL_PLAN_TOOLS
from app.tools.shopping_list import price_shopping_list

SLOTS = ["breakfast", "lunch", "dinner"]


def _duration_to_days(duration: str) -> int:
    d = duration.strip().lower()
    if "week" in d:
        match = re.search(r"\d+", d)
        return 7 * (int(match.group()) if match else 1)
    match = re.search(r"\d+", d)
    return int(match.group()) if match else 3


class MealPlanError(RuntimeError):
    pass


def _fetch_slot_candidates(
    db: FoodDB, slot: str, cook_time_category: str, pantry: list[str], preference: list[str], allergy: list[str]
) -> tuple[list[dict], bool]:
    """Runs get_foods directly rather than making the model call it — same
    reasoning as pricing: this is a deterministic lookup with no judgment
    call in it, and letting the model own it burned its tool-call budget on
    redundant re-fetches once the candidate pools got large (30+ for some
    slots against the full dataset, vs. a handful in the placeholder data).

    Returns (candidates, preference_was_relaxed).
    """
    results = get_foods(db, slot=slot, cook_time_category=cook_time_category, source={"type": "pantry", "items": pantry}, preference=preference, allergy=allergy)
    if results or not preference:
        return results, False
    # nothing matched with the stated preference — relax it for this slot
    # only, same fallback behavior previously left to the model
    return get_foods(db, slot=slot, cook_time_category=cook_time_category, source={"type": "pantry", "items": pantry}, preference=[], allergy=allergy), True


def _trim_candidate(c: dict) -> dict:
    return {
        "id": c["id"],
        "name": c["name"],
        "kcal": c["kcal"],
        "protein_g": c["protein_g"],
        "cook_time_mins": c["cook_time_mins"],
        "estimated_cost": c["estimated_cost"],
    }


def _enforce_budget(
    db: FoodDB, have_ids: set[str], plan_slots: list[dict], candidates_by_slot: dict[str, list[dict]], budget: float
) -> None:
    """Mutates plan_slots' dish_ids in place until the total is at or under
    budget, or every slot instance is already at its slot's cheapest
    available candidate (the true minimum — can't do better).

    Deliberately not left to the model: it was asked to do this in the
    prompt and mostly did, but "mostly" isn't good enough for a budget
    constraint — this is arithmetic + comparison with no judgment call in
    it, so it's guaranteed correct in code instead of hoped-for from the LLM.
    """

    def cost_of(dish_id: str) -> float:
        return dish_cost(db, db.dishes[dish_id], have_ids)[0]

    cheapest_by_slot: dict[str, str] = {}
    for slot, candidates in candidates_by_slot.items():
        if candidates:
            cheapest_by_slot[slot] = min(candidates, key=lambda c: c["estimated_cost"])["id"]

    while sum(cost_of(ps["dish_id"]) for ps in plan_slots) > budget:
        most_expensive_first = sorted(plan_slots, key=lambda ps: -cost_of(ps["dish_id"]))
        swapped = False
        for ps in most_expensive_first:
            cheapest_id = cheapest_by_slot.get(ps["slot"])
            if cheapest_id and cheapest_id != ps["dish_id"] and cost_of(cheapest_id) < cost_of(ps["dish_id"]):
                ps["dish_id"] = cheapest_id
                swapped = True
                break
        if not swapped:
            return  # every instance is already at its slot's cheapest — genuinely infeasible


def generate_meal_plan(
    provider: ModelProvider,
    db: FoodDB,
    budget: float,
    duration: str,
    slot_cook_time: dict[str, str],
    preference: list[str],
    allergy: list[str],
    pantry: list[str],
) -> dict:
    num_days = _duration_to_days(duration)
    slot_cook_time_norm = {k.lower(): v.lower() for k, v in slot_cook_time.items()}

    candidates_by_slot: dict[str, list[dict]] = {}
    relaxed_slots: list[str] = []
    for slot in SLOTS:
        cook_time = slot_cook_time_norm.get(slot, "intermediate")
        results, relaxed = _fetch_slot_candidates(db, slot, cook_time, pantry, preference, allergy)
        candidates_by_slot[slot] = [_trim_candidate(c) for c in results]
        if relaxed:
            relaxed_slots.append(slot)

    request_desc = {
        "budget_naira": budget,
        "num_days": num_days,
        "slots_per_day": SLOTS,
        "candidates_by_slot": candidates_by_slot,
        "note": (
            f"No candidates matched your stated preference for: {', '.join(relaxed_slots)}, so preference "
            "was dropped for those slots only — the listed candidates already reflect that."
            if relaxed_slots
            else None
        ),
    }
    messages = [
        {"role": "system", "content": MEAL_PLAN_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                "Build my meal plan from these pre-fetched candidates — one dish per day per slot, for "
                f"{num_days} days:\n{json.dumps(request_desc, indent=2)}"
            ),
        },
    ]

    _, plan_args = run_agent_loop(
        provider,
        db,
        messages,
        MEAL_PLAN_TOOLS,
        settings.agent_max_tool_iterations,
        terminal_tool_name="submit_meal_plan",
    )
    if plan_args is None:
        raise MealPlanError("Model finished without calling submit_meal_plan")

    try:
        plan = SubmitMealPlanArgs.model_validate(plan_args)
    except ValidationError as e:
        # A structured, typed parse of the model's own final answer — this
        # is what catches a malformed/partial submit_meal_plan call (missing
        # slot, wrong shape, etc.) as a clear error here rather than a
        # KeyError three lines into aggregation.
        raise MealPlanError(f"Model's submit_meal_plan call didn't match the expected shape: {e.errors()}") from e

    have_ids = resolve_have_ids(db, pantry)

    # flat (day, slot, dish_id) list — cheap to validate and swap on, the
    # full display objects get built once at the end from whatever survives
    plan_slots = [
        {"day": day.day, "slot": slot_entry.slot, "dish_id": slot_entry.dish_id}
        for day in plan.days
        for slot_entry in day.slots
    ]
    for ps in plan_slots:
        if ps["dish_id"] not in db.dishes:
            raise MealPlanError(f"Model referenced unknown dish_id {ps['dish_id']!r}")

    _enforce_budget(db, have_ids, plan_slots, candidates_by_slot, budget)

    days_map: dict[str, list[dict]] = {}
    missing_by_dish = []
    total_kcal = 0
    total_protein = 0
    for ps in plan_slots:
        dish = db.dishes[ps["dish_id"]]
        cost, uses_pantry, missing = dish_cost(db, dish, have_ids)
        missing_by_dish.append(missing)
        total_kcal += dish.kcal_per_serving
        total_protein += dish.protein_per_serving_g
        days_map.setdefault(ps["day"], []).append(
            {
                "slot": ps["slot"],
                "dish_id": dish.id,
                "name": dish.name,
                "kcal": dish.kcal_per_serving,
                "protein_g": dish.protein_per_serving_g,
                "cook_time_mins": dish.cook_time_mins,
                "estimated_cost": cost,
                "uses_pantry_items": uses_pantry,
            }
        )
    days_out = [{"day": day, "slots": slots} for day, slots in days_map.items()]

    shopping_list = price_shopping_list(db, missing_by_dish)
    slot_count = len(plan_slots)
    avg_kcal = round(total_kcal / slot_count) if slot_count else 0
    avg_protein = round(total_protein / slot_count) if slot_count else 0

    return {
        "days": days_out,
        "shopping_list": shopping_list,
        "total_cost": shopping_list["total"],
        "budget": budget,
        "within_budget": shopping_list["total"] <= budget,
        "avg_kcal_per_meal": avg_kcal,
        "avg_protein_per_meal_g": avg_protein,
    }
