from __future__ import annotations

from app.data.loader import FoodDB


def price_items_by_name(db: FoodDB, items: list[dict]) -> dict:
    """Ad-hoc pricing for a raw list of {name, quantity} — e.g. a one-off
    chat question like "how much would eggs and rice cost me". Not
    quantity-aware across a whole plan; see `price_shopping_list` for that.
    """
    lines = []
    total = 0.0
    for item in items:
        ing = db.find_ingredient_by_name(item["name"])
        if ing is None:
            lines.append({"name": item["name"], "quantity": item.get("quantity", 1), "unit": None, "unit_price": None, "subtotal": None, "note": "unknown ingredient"})
            continue
        qty = item.get("quantity", 1)
        subtotal = round(qty * ing.price_per_unit, 2)
        total += subtotal
        lines.append({"name": ing.name, "quantity": qty, "unit": ing.unit, "unit_price": ing.price_per_unit, "subtotal": subtotal})
    return {"items": lines, "total": round(total, 2)}


def price_shopping_list(db: FoodDB, missing_items_by_dish: list[list[dict]]) -> dict:
    """The real aggregation step: dedupe + sum quantities for every missing
    ingredient across *all* dishes in an assembled plan, then price once.

    `missing_items_by_dish` is a list of each dish's `missing_items` (as
    returned by `get_foods`) — one list per chosen meal for the week.
    Deliberately deterministic, not an LLM tool call: pure arithmetic with
    no judgment calls, so it runs automatically after planning finishes
    rather than relying on the model to remember to invoke it.
    """
    totals: dict[str, dict] = {}
    for dish_missing in missing_items_by_dish:
        for line in dish_missing:
            key = line["ingredient_id"]
            if key not in totals:
                totals[key] = {"ingredient_id": key, "name": line["name"], "quantity": 0.0, "unit": line["unit"]}
            totals[key]["quantity"] += line["quantity"]

    lines = []
    grand_total = 0.0
    for key, agg in totals.items():
        ing = db.ingredients[key]
        qty = round(agg["quantity"], 3)
        subtotal = round(qty * ing.price_per_unit, 2)
        grand_total += subtotal
        lines.append({"name": ing.name, "quantity": qty, "unit": ing.unit, "unit_price": ing.price_per_unit, "subtotal": subtotal})

    lines.sort(key=lambda l: -l["subtotal"])
    return {"items": lines, "total": round(grand_total, 2)}
