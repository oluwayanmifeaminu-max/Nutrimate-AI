from __future__ import annotations

from app.data.loader import FoodDB


def get_recipe(db: FoodDB, food: str) -> dict | None:
    dish = db.find_dish_by_name(food)
    if dish is None:
        return None
    return {
        "id": dish.id,
        "name": dish.name,
        "servings": dish.servings,
        "ingredients": [
            {
                "name": db.ingredients[line.ingredient_id].name,
                "quantity": line.quantity,
                "unit": line.unit,
            }
            for line in dish.ingredients
        ],
        "steps": dish.steps,
        "cook_time_mins": dish.cook_time_mins,
        "kcal_per_serving": dish.kcal_per_serving,
        "protein_per_serving_g": dish.protein_per_serving_g,
    }
