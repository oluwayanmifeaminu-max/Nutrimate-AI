"""OpenAI-style function-calling tool schemas. Both providers (Ollama and
OpenRouter) consume this same shape.
"""

GET_FOODS = {
    "type": "function",
    "function": {
        "name": "get_foods",
        "description": (
            "Find candidate dishes for one meal slot, filtered by cook time, diet preference and "
            "allergies, and priced against what's missing from a pantry or ingredient list."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "slot": {"type": "string", "enum": ["breakfast", "lunch", "dinner", "snack"]},
                "cook_time_category": {"type": "string", "enum": ["fast", "intermediate", "long"]},
                "source": {
                    "type": "object",
                    "description": "What's available to cook with.",
                    "properties": {
                        "type": {"type": "string", "enum": ["pantry", "list"]},
                        "items": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Ingredient names available, e.g. the user's pantry contents.",
                        },
                    },
                    "required": ["type", "items"],
                },
                "preference": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Diet preference tags, e.g. 'High Protein', 'Halal'.",
                },
                "allergy": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Allergens to exclude, e.g. 'Peanut', 'Gluten'.",
                },
            },
            "required": ["slot", "cook_time_category", "source"],
        },
    },
}

GET_RECIPE = {
    "type": "function",
    "function": {
        "name": "get_recipe",
        "description": "Get the full recipe (ingredients with quantities, and steps) for a named dish.",
        "parameters": {
            "type": "object",
            "properties": {"food": {"type": "string", "description": "Dish name, e.g. 'Jollof Rice & Beans'."}},
            "required": ["food"],
        },
    },
}

SEARCH_INGREDIENT = {
    "type": "function",
    "function": {
        "name": "search_ingredient",
        "description": (
            "Check whether a specific ingredient is one of the staples tracked locally for pantry/pricing "
            "(returns its category, price, allergens if so). This is a small local dataset, not a general "
            "food database — a 'not found' result does NOT mean the food is unhealthy, unusual, or not "
            "real. Use this for pantry/pricing context, not to judge whether something is nutritious — "
            "answer nutrition-quality questions from your own knowledge regardless of whether it's found."
        ),
        "parameters": {
            "type": "object",
            "properties": {"name": {"type": "string", "description": "e.g. 'spinach', 'kiwi'"}},
            "required": ["name"],
        },
    },
}

CALCULATOR = {
    "type": "function",
    "function": {
        "name": "calculator",
        "description": "Evaluate an arithmetic expression. Use this for any budget math or totals instead of computing it yourself.",
        "parameters": {
            "type": "object",
            "properties": {"expression": {"type": "string", "description": "e.g. '12000 - 4850'"}},
            "required": ["expression"],
        },
    },
}

PRICE_SHOPPING_LIST = {
    "type": "function",
    "function": {
        "name": "price_shopping_list",
        "description": (
            "Estimate the price of a list of ingredients/foods the user names, e.g. answering "
            "'how much would eggs and rice cost me'. Not for pricing a full meal plan — that's priced "
            "automatically once you finish planning."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "quantity": {"type": "number", "description": "In the ingredient's natural unit, defaults to 1"},
                        },
                        "required": ["name"],
                    },
                }
            },
            "required": ["items"],
        },
    },
}

SUBMIT_MEAL_PLAN = {
    "type": "function",
    "function": {
        "name": "submit_meal_plan",
        "description": (
            "Submit your final selected meal plan once you've chosen one dish for every requested day "
            "and slot. Call this exactly once when you're done deciding — it ends the planning process."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "days": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "day": {"type": "string", "description": "e.g. 'Day 1' or 'Monday'"},
                            "slots": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "slot": {"type": "string", "enum": ["breakfast", "lunch", "dinner", "snack"]},
                                        "dish_id": {"type": "string", "description": "id of the chosen dish, from get_foods results"},
                                    },
                                    "required": ["slot", "dish_id"],
                                },
                            },
                        },
                        "required": ["day", "slots"],
                    },
                }
            },
            "required": ["days"],
        },
    },
}

CHAT_TOOLS = [GET_FOODS, GET_RECIPE, SEARCH_INGREDIENT, CALCULATOR, PRICE_SHOPPING_LIST]
# No calculator here: budget arithmetic is enforced deterministically after
# submit_meal_plan (see _enforce_budget), and offering the tool led the model
# to compulsively re-verify the same total 8+ times instead of submitting —
# removing it structurally rules that out rather than relying on prompt wording.
MEAL_PLAN_TOOLS = [GET_FOODS, GET_RECIPE, SUBMIT_MEAL_PLAN]
