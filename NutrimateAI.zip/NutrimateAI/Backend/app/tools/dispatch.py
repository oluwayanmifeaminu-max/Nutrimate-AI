from __future__ import annotations

from typing import Any

from pydantic import ValidationError

from app.data.loader import FoodDB
from app.tools.args_models import CalculatorArgs, GetFoodsArgs, GetRecipeArgs, PriceShoppingListArgs, SearchIngredientArgs
from app.tools.calculator import CalculatorError, calculator
from app.tools.get_foods import get_foods
from app.tools.get_recipe import get_recipe
from app.tools.search_ingredient import search_ingredient
from app.tools.shopping_list import price_items_by_name

# submit_meal_plan is deliberately excluded: it's a terminal "final answer"
# signal handled specially by the meal-plan agent loop (validated separately
# via SubmitMealPlanArgs there), not something to execute and feed a result
# back for.
EXECUTABLE_TOOLS = {"get_foods", "get_recipe", "search_ingredient", "calculator", "price_shopping_list"}


def execute_tool(db: FoodDB, name: str, arguments: dict[str, Any]) -> dict:
    try:
        if name == "get_foods":
            args = GetFoodsArgs.model_validate(arguments)
            return {
                "results": get_foods(
                    db,
                    slot=args.slot,
                    cook_time_category=args.cook_time_category,
                    source=args.source.model_dump(),
                    preference=args.preference,
                    allergy=args.allergy,
                )
            }
        if name == "get_recipe":
            args = GetRecipeArgs.model_validate(arguments)
            recipe = get_recipe(db, args.food)
            return recipe if recipe is not None else {"error": f"No recipe found for {args.food!r}"}
        if name == "search_ingredient":
            args = SearchIngredientArgs.model_validate(arguments)
            return search_ingredient(db, args.name)
        if name == "calculator":
            args = CalculatorArgs.model_validate(arguments)
            try:
                return {"result": calculator(args.expression)}
            except CalculatorError as e:
                return {"error": str(e)}
        if name == "price_shopping_list":
            args = PriceShoppingListArgs.model_validate(arguments)
            return price_items_by_name(db, [item.model_dump() for item in args.items])
    except ValidationError as e:
        # Fed back to the model as the tool result, so it can see exactly
        # what was wrong with its own arguments and retry rather than the
        # request crashing outright.
        return {"error": f"Invalid arguments for {name}: {e.errors()}"}

    return {"error": f"Unknown tool {name!r}"}
