"""Pydantic models the model's tool-call arguments are validated against
before we trust them. The JSON schemas shown *to* the LLM (schemas.py) stay
hand-written and flat — nested $ref/$defs schemas are harder for a model to
follow and untested against these providers — but everything that comes
*back* from a tool call is parsed through one of these before it touches
application logic, so a malformed or partial call fails with a clear
validation error instead of a KeyError deep in aggregation code.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

Slot = Literal["breakfast", "lunch", "dinner", "snack"]
CookTimeCategory = Literal["fast", "intermediate", "long"]


class FoodSource(BaseModel):
    type: Literal["pantry", "list"] = "pantry"
    items: list[str] = Field(default_factory=list)


class GetFoodsArgs(BaseModel):
    slot: Slot
    cook_time_category: CookTimeCategory
    source: FoodSource = Field(default_factory=FoodSource)
    preference: list[str] = Field(default_factory=list)
    allergy: list[str] = Field(default_factory=list)


class GetRecipeArgs(BaseModel):
    food: str


class SearchIngredientArgs(BaseModel):
    name: str


class CalculatorArgs(BaseModel):
    expression: str


class PriceItem(BaseModel):
    name: str
    quantity: float = 1


class PriceShoppingListArgs(BaseModel):
    items: list[PriceItem]


class MealSlotSelection(BaseModel):
    slot: Slot
    dish_id: str


class DayPlan(BaseModel):
    day: str
    slots: list[MealSlotSelection]


class SubmitMealPlanArgs(BaseModel):
    days: list[DayPlan]
