from __future__ import annotations

from app.data.loader import FoodDB, Ingredient


def _to_dict(ing: Ingredient) -> dict:
    return {
        "found": True,
        "name": ing.name,
        "category": ing.category,
        "unit": ing.unit,
        "price_per_unit": ing.price_per_unit,
        "allergen_tags": ing.allergen_tags,
        "perishable": ing.perishable,
    }


def search_ingredient(db: FoodDB, name: str) -> dict:
    """Checks whether `name` is one of the ~78 staples this app tracks
    locally for pantry/pricing purposes. This is NOT a general food
    database — a "not found" result says nothing about whether something
    is a real or nutritious food, only that this small demo dataset
    doesn't happen to price it. The note field spells that out explicitly
    so the model can't misread absence as a verdict.
    """
    exact = db.find_ingredient_by_name(name)
    if exact:
        return _to_dict(exact)

    query = name.strip().lower()
    for ing in db.ingredients.values():
        names = [ing.name.lower(), *[a.lower() for a in ing.aliases]]
        if any(query in n or n in query for n in names):
            return _to_dict(ing)

    return {
        "found": False,
        "note": (
            f"{name!r} is not one of the ~78 staple ingredients tracked locally for pantry/pricing. "
            "This is a small demo dataset, not a general food database — being absent here does NOT mean "
            "it isn't a real or nutritious food. Answer any nutrition question about it from general "
            "knowledge as usual."
        ),
    }
