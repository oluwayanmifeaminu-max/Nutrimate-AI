from __future__ import annotations

from app.data.loader import Dish, FoodDB


def _normalize_tag(s: str) -> str:
    return s.strip().lower().replace(" ", "_").replace("-", "_")


def resolve_have_ids(db: FoodDB, item_names: list[str]) -> set[str]:
    ids: set[str] = set()
    for name in item_names:
        ing = db.find_ingredient_by_name(name)
        if ing:
            ids.add(ing.id)
    return ids


def dish_cost(db: FoodDB, dish: Dish, have_ids: set[str]) -> tuple[float, list[str], list[dict]]:
    cost = 0.0
    uses_pantry: list[str] = []
    missing: list[dict] = []
    for line in dish.ingredients:
        ing = db.ingredients[line.ingredient_id]
        if line.ingredient_id in have_ids:
            uses_pantry.append(ing.name)
        else:
            # quantity/unit carried through so a later shopping-list pass can
            # sum this ingredient's need across every dish in a whole plan,
            # not just flag that it's needed.
            missing.append({"ingredient_id": ing.id, "name": ing.name, "quantity": line.quantity, "unit": line.unit})
            cost += line.quantity * ing.price_per_unit
    return round(cost, 2), uses_pantry, missing


def get_foods(
    db: FoodDB,
    slot: str,
    cook_time_category: str,
    source: dict,
    preference: list[str] | None = None,
    allergy: list[str] | None = None,
) -> list[dict]:
    """Candidate dishes for a meal slot, filtered by cook time / diet / allergy,
    priced against what's missing from the given pantry (or hypothetical list).
    """
    have_ids = resolve_have_ids(db, source.get("items", []))
    pref_tags = {_normalize_tag(p) for p in (preference or [])}
    allergy_tags = {_normalize_tag(a) for a in (allergy or [])}
    slot_norm = slot.strip().lower()
    cook_time_norm = cook_time_category.strip().lower()

    results = []
    for dish in db.dishes.values():
        if slot_norm not in [s.lower() for s in dish.slots]:
            continue
        if dish.cook_time_category != cook_time_norm:
            continue
        if pref_tags and not pref_tags.issubset(set(dish.diet_tags)):
            continue
        if allergy_tags and (allergy_tags & db.dish_allergens(dish)):
            continue

        cost, uses_pantry, missing = dish_cost(db, dish, have_ids)
        results.append(
            {
                "id": dish.id,
                "name": dish.name,
                "slot": slot,
                "kcal": dish.kcal_per_serving,
                "protein_g": dish.protein_per_serving_g,
                "cook_time_mins": dish.cook_time_mins,
                "uses_pantry_items": uses_pantry,
                "missing_items": missing,
                "estimated_cost": cost,
            }
        )

    results.sort(key=lambda r: r["estimated_cost"])
    return results
