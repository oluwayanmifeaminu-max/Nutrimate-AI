"""SQLModel table definitions — the actual persistent store. Ingredients and
dishes are seeded once from the JSON research data (app/seed.py); pantry is
live, mutable, user-owned state with no prefill.
"""

from __future__ import annotations

from sqlmodel import JSON, Column, Field, SQLModel


class IngredientRow(SQLModel, table=True):
    __tablename__ = "ingredients"

    id: str = Field(primary_key=True)
    name: str
    aliases: list[str] = Field(sa_column=Column(JSON), default_factory=list)
    category: str
    unit: str
    price_per_unit: float
    allergen_tags: list[str] = Field(sa_column=Column(JSON), default_factory=list)
    shelf_life_days: int
    perishable: bool


class DishRow(SQLModel, table=True):
    __tablename__ = "dishes"

    id: str = Field(primary_key=True)
    name: str
    description: str = ""
    slots: list[str] = Field(sa_column=Column(JSON), default_factory=list)
    cook_time_mins: int
    servings: int = 1
    kcal_per_serving: int = 0
    protein_per_serving_g: int = 0
    diet_tags: list[str] = Field(sa_column=Column(JSON), default_factory=list)
    steps: list[str] = Field(sa_column=Column(JSON), default_factory=list)


class DishIngredientRow(SQLModel, table=True):
    __tablename__ = "dish_ingredients"

    id: int | None = Field(default=None, primary_key=True)
    dish_id: str = Field(foreign_key="dishes.id", index=True)
    ingredient_id: str = Field(foreign_key="ingredients.id", index=True)
    quantity: float
    unit: str


class PantryItemRow(SQLModel, table=True):
    __tablename__ = "pantry_items"

    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(unique=True)
    qty: str = "—"
    cat: str = "Other"
    tag: str = "Fresh"
    level: str = "ok"
