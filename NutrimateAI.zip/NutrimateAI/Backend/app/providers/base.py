from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ProviderResponse:
    content: str | None
    tool_calls: list[ToolCall]


class ModelProvider(Protocol):
    """Common interface every model backend (Ollama, OpenRouter, ...) implements.

    Tool schemas are OpenAI-style function-calling JSON (the `tools=[...]`
    shape), since both Ollama's and OpenRouter's APIs speak that format.
    """

    def chat(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> ProviderResponse: ...
