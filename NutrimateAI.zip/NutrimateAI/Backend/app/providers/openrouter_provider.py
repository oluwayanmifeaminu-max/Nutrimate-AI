from __future__ import annotations

import json
from typing import Any

from openai import OpenAI

from app.providers.base import ProviderResponse, ToolCall


class OpenRouterProvider:
    """Talks to OpenRouter's OpenAI-compatible chat completions API."""

    def __init__(self, api_key: str, base_url: str, model: str):
        if not api_key:
            raise ValueError("OPENROUTER_API_KEY is required when MODEL_PROVIDER=openrouter")
        self._client = OpenAI(api_key=api_key, base_url=base_url)
        self._model = model

    def chat(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> ProviderResponse:
        resp = self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            tools=tools or None,
        )
        message = resp.choices[0].message
        tool_calls = [
            ToolCall(
                id=tc.id,
                name=tc.function.name,
                arguments=json.loads(tc.function.arguments or "{}"),
            )
            for tc in (message.tool_calls or [])
        ]
        return ProviderResponse(content=message.content, tool_calls=tool_calls)
