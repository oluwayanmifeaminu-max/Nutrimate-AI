from __future__ import annotations

from typing import Any

import ollama

from app.providers.base import ProviderResponse, ToolCall


class OllamaProvider:
    """Talks to a local `ollama serve` daemon.

    This also covers Ollama Cloud: cloud vs local is decided by the model
    tag (e.g. "gemma4:e4b" runs fully local, "gemma4:31b-cloud" is proxied to
    Ollama Cloud by the daemon itself), not by a different host. `api_key` is
    only needed for setups that require it outside of `ollama signin`.
    """

    def __init__(self, host: str, model: str, api_key: str = ""):
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else None
        self._client = ollama.Client(host=host, headers=headers)
        self._model = model

    def chat(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> ProviderResponse:
        resp = self._client.chat(model=self._model, messages=messages, tools=tools or None)
        message = resp["message"]
        tool_calls = [
            ToolCall(
                id=tc.get("id") or f"call_{i}",
                name=tc["function"]["name"],
                arguments=dict(tc["function"]["arguments"]),
            )
            for i, tc in enumerate(message.get("tool_calls") or [])
        ]
        return ProviderResponse(content=message.get("content") or None, tool_calls=tool_calls)
