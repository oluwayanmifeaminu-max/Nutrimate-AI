from app.config import settings
from app.providers.base import ModelProvider
from app.providers.ollama_provider import OllamaProvider
from app.providers.openrouter_provider import OpenRouterProvider


def get_provider() -> ModelProvider:
    if settings.model_provider == "ollama":
        return OllamaProvider(host=settings.ollama_host, model=settings.model_name, api_key=settings.ollama_api_key)
    if settings.model_provider == "openrouter":
        return OpenRouterProvider(
            api_key=settings.openrouter_api_key,
            base_url=settings.openrouter_base_url,
            model=settings.model_name,
        )
    raise ValueError(f"Unknown MODEL_PROVIDER {settings.model_provider!r}, expected 'ollama' or 'openrouter'")
