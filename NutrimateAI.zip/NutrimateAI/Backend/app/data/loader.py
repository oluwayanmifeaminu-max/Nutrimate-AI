"""Loads ingredients/dishes from SQLite into indexed, queryable in-memory
structures at startup. SQLite is the runtime source of truth (seeded once
from the research JSON files, see app/seed.py); this loader just builds fast
in-memory lookups the tools query — nothing in app/tools/ needs to know or
care that the data originally came from a database.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from sqlmodel import select

from app.db import get_session
from app.db_models import DishIngredientRow, DishRow, IngredientRow
from app.seed import seed_if_empty

# cook_time_mins -> cook_time_category bands.
# The product spec's bands ("5-10 fast", "30-60 intermediate", "60-120 long")
# leave an 11-29min gap uncovered by real recipes, so intermediate is
# extended down to cover it: <=10 fast, <=60 intermediate, else long.
FAST_MAX_MINS = 10
INTERMEDIATE_MAX_MINS = 60


def cook_time_category(mins: int) -> str:
    if mins <= FAST_MAX_MINS:
        return "fast"
    if mins <= INTERMEDIATE_MAX_MINS:
        return "intermediate"
    return "long"


@dataclass
class Ingredient:
    id: str
    name: str
    aliases: list[str]
    category: str
    unit: str
    price_per_unit: float
    allergen_tags: list[str]
    shelf_life_days: int
    perishable: bool


@dataclass
class RecipeLine:
    ingredient_id: str
    quantity: float
    unit: str


@dataclass
class Dish:
    id: str
    name: str
    description: str
    slots: list[str]
    cook_time_mins: int
    servings: int
    kcal_per_serving: int
    protein_per_serving_g: int
    diet_tags: list[str]
    ingredients: list[RecipeLine]
    steps: list[str]
    cook_time_category: str = field(init=False)

    def __post_init__(self):
        self.cook_time_category = cook_time_category(self.cook_time_mins)


class FoodDB:
    def __init__(self):
        self.ingredients: dict[str, Ingredient] = {}
        self.dishes: dict[str, Dish] = {}
        self._name_to_ingredient_id: dict[str, str] = {}
        self._load()

    def _load(self) -> None:
        seed_if_empty()
        with get_session() as session:
            for row in session.exec(select(IngredientRow)):
                ing = Ingredient(
                    id=row.id,
                    name=row.name,
                    aliases=row.aliases,
                    category=row.category,
                    unit=row.unit,
                    price_per_unit=row.price_per_unit,
                    allergen_tags=row.allergen_tags,
                    shelf_life_days=row.shelf_life_days,
                    perishable=row.perishable,
                )
                self.ingredients[ing.id] = ing
                for name in [ing.name, *ing.aliases]:
                    self._name_to_ingredient_id[name.strip().lower()] = ing.id

            recipe_lines: dict[str, list[RecipeLine]] = {}
            for li in session.exec(select(DishIngredientRow)):
                recipe_lines.setdefault(li.dish_id, []).append(
                    RecipeLine(li.ingredient_id, li.quantity, li.unit)
                )

            for row in session.exec(select(DishRow)):
                dish = Dish(
                    id=row.id,
                    name=row.name,
                    description=row.description,
                    slots=row.slots,
                    cook_time_mins=row.cook_time_mins,
                    servings=row.servings,
                    kcal_per_serving=row.kcal_per_serving,
                    protein_per_serving_g=row.protein_per_serving_g,
                    diet_tags=row.diet_tags,
                    ingredients=recipe_lines.get(row.id, []),
                    steps=row.steps,
                )
                for line in dish.ingredients:
                    if line.ingredient_id not in self.ingredients:
                        raise ValueError(f"Dish {dish.id!r} references unknown ingredient {line.ingredient_id!r}")
                self.dishes[dish.id] = dish

    def find_ingredient_by_name(self, name: str) -> Ingredient | None:
        ing_id = self._name_to_ingredient_id.get(name.strip().lower())
        return self.ingredients.get(ing_id) if ing_id else None

    def find_dish_by_name(self, name: str) -> Dish | None:
        target = name.strip().lower()
        for dish in self.dishes.values():
            if dish.name.strip().lower() == target or dish.id == target:
                return dish
        # loose fallback: substring match
        for dish in self.dishes.values():
            if target in dish.name.strip().lower():
                return dish
        return None

    def dish_allergens(self, dish: Dish) -> set[str]:
        tags: set[str] = set()
        for line in dish.ingredients:
            tags |= set(self.ingredients[line.ingredient_id].allergen_tags)
        return tags


_db: FoodDB | None = None


def get_db() -> FoodDB:
    global _db
    if _db is None:
        _db = FoodDB()
    return _db
