"""One-time seed of ingredients/dishes from the research JSON files into
SQLite. Idempotent — does nothing if the ingredients table already has rows,
so it's safe to call on every app startup.

The JSON files remain in app/data/ as the reviewable/versioned seed source
(this is what the research agent produces); SQLite is the runtime store.
"""

from __future__ import annotations

import json
from pathlib import Path

from sqlmodel import Session, select

from app.db import get_session, init_db
from app.db_models import DishIngredientRow, DishRow, IngredientRow

DATA_DIR = Path(__file__).parent / "data"


def seed_if_empty() -> None:
    init_db()
    with get_session() as session:
        if session.exec(select(IngredientRow)).first() is not None:
            return  # already seeded
        _seed(session)


def _seed(session: Session) -> None:
    ingredients = json.loads((DATA_DIR / "ingredients.json").read_text())
    dishes = json.loads((DATA_DIR / "dishes.json").read_text())

    for row in ingredients:
        session.add(
            IngredientRow(
                id=row["id"],
                name=row["name"],
                aliases=row.get("aliases", []),
                category=row["category"],
                unit=row["unit"],
                price_per_unit=row["price_per_unit"],
                allergen_tags=row.get("allergen_tags", []),
                shelf_life_days=row.get("shelf_life_days", 0),
                perishable=row.get("perishable", True),
            )
        )

    for row in dishes:
        session.add(
            DishRow(
                id=row["id"],
                name=row["name"],
                description=row.get("description", ""),
                slots=row["slots"],
                cook_time_mins=row["cook_time_mins"],
                servings=row.get("servings", 1),
                kcal_per_serving=row.get("kcal_per_serving", 0),
                protein_per_serving_g=row.get("protein_per_serving_g", 0),
                diet_tags=row.get("diet_tags", []),
                steps=row.get("steps", []),
            )
        )
        for line in row["ingredients"]:
            session.add(
                DishIngredientRow(
                    dish_id=row["id"],
                    ingredient_id=line["ingredient_id"],
                    quantity=line["quantity"],
                    unit=line["unit"],
                )
            )

    session.commit()


if __name__ == "__main__":
    seed_if_empty()
    print("Seed complete.")
